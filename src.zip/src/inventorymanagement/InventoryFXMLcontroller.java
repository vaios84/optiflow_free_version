
package inventorymanagement;

import dbUtil.dbConnection;
import dbUtil.loadCategories;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import readWriteLog.ReadWriteLog;
import students.ProductData;

public class InventoryFXMLcontroller implements Initializable{

  
  @FXML
  private TextField id;
  @FXML
  private TextField pname;
  @FXML
  private TextField size;  
  @FXML
  private TextField qty;
  @FXML
  private TextField location;
  
  // create combobox category and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> category;
  private ObservableList<String> list = FXCollections.observableArrayList();
  
  // create combobox sub-category and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> subcategory;
  private ObservableList<String> sublist = FXCollections.observableArrayList("Select category");
  
  @FXML
  private TextField price;
  
  // create combobox and a suppliers list to connect it later inside initialize function
  @FXML
  private ComboBox<String> supplier;
  private ObservableList<String> supplierlist;
  
  @FXML
  private TableView<ProductData> producttable;
  @FXML
  private TableColumn<ProductData, String> idcolumn;
  @FXML
  private TableColumn<ProductData, String> pnamecolumn;
  @FXML
  private TableColumn<ProductData, String> sizecolumn;
  @FXML
  private TableColumn<ProductData, Integer> qtycolumn;    
  @FXML
  private TableColumn<ProductData, String> locationcolumn;
  @FXML
  private TableColumn<ProductData, String> catcolumn;
  @FXML
  private TableColumn<ProductData, String> subcatcolumn;
  @FXML
  private TableColumn<ProductData, Double> pricecolumn;
  @FXML
  private TableColumn<ProductData, String> scolumn;
  
  @FXML
  private Button findbutton;
  @FXML
  private Button loadbutton;
  @FXML
  private Button productMinusOne;
  @FXML
  private Button productPlusOne;
  @FXML
  private Button productPlusTen;
  @FXML
  private Button addbutton;
  @FXML
  private Button removebutton;
  @FXML
  private Button clearbutton;
  @FXML
  private Button printbutton;
  @FXML
  private Button logreadbutton;
  @FXML
  private Button openUpdatebutton;  
  
  
  private ObservableList<ProductData> data;  
  private dbConnection dc;
  
  private static boolean flagAlertBox=true;
  
  @Override
  public void initialize(URL url, ResourceBundle rb) {
      this.dc = new dbConnection();
      
      // populating the list with the categories from the sql database
      loadCategories ob1 = new loadCategories();
      list = ob1.getCategories();
      
      // connect combobox and list of items for category combobox
      category.setItems(list);
      
      // connect combobox and list of items for sub-category combobox
      subcategory.setItems(sublist);
      
      
      // connect combobox and list of items for Suppliers Combobox
      try{
            Connection conn = dbConnection.getConnection();
            this.supplierlist = FXCollections.observableArrayList();
            
            ResultSet rs2 = conn.createStatement().executeQuery("SELECT company FROM suppliers");
            while (rs2.next()) {
                this.supplierlist.add(rs2.getString(1));
            }      
            
            supplier.setItems(supplierlist);
            
            conn.close();
            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      
      // call loadProductData2 in order the app to load the data for the first time (but not show them in the table) 
      // now the app is able to scan (and find) a product 
      loadProductData2();
      
      // make a textfield (id) automatically clicked with cursor and ready for user (or barcode scanner) input
      Platform.runLater(new Runnable() {
        @Override
        public void run() {
            id.requestFocus();
        }
      });
    
      // product id typing or scanning and listen for ENTER key, then sell a product
      // barcode scanners provide automatically a barcode ID and ENTER key
      id.setOnKeyPressed(new EventHandler<KeyEvent>()
      {
        @Override
        public void handle(KeyEvent ke)
        {   
                        
            if (ke.getCode().equals(KeyCode.ENTER))
            {
               findProduct2();
               
            }
        }
      });
      
      
      
  }
  
  @FXML
  private void loadProductData(ActionEvent event){
      
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            boolean isCategoryEmpty = category.getSelectionModel().isEmpty();
            boolean isSubcategoryEmpty = subcategory.getSelectionModel().isEmpty();
            boolean isSupplierEmpty = supplier.getSelectionModel().isEmpty();
            
            // the percent sign % in sql means whatever string (matches every sequence of chars)
            
            // here we set initial values at the four variables
            String tempcat="%", tempsub="%", tempsup="%";
            
            // read users choices in the comboboxes (only if the user has selected something)
            if (!isCategoryEmpty) tempcat = this.category.getValue();
            if (!isCategoryEmpty && !isSubcategoryEmpty) tempsub = this.subcategory.getValue();
            if (!isSupplierEmpty) tempsup = this.supplier.getValue();
            
            ResultSet rs = conn.createStatement().executeQuery(new StringBuilder().append("SELECT * FROM products WHERE category LIKE '").append(tempcat).append("' AND subcategory LIKE '").append(tempsub).append("' AND supplier LIKE '").append(tempsup).append("'").toString());
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
            }   
            
            conn.close();            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.sizecolumn.setCellValueFactory(new PropertyValueFactory("size"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.locationcolumn.setCellValueFactory(new PropertyValueFactory("location"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.subcatcolumn.setCellValueFactory(new PropertyValueFactory("subcategory"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
      
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
  } 
  
  // loadProductData2 function to be used inside initialize function
  private void loadProductData2() {
      
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            ResultSet rs;
            rs = conn.createStatement().executeQuery("SELECT * FROM products");
            
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
            }   
            
            conn.close();            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
  }
  
  
  
  @FXML
  private void findProduct(ActionEvent event){
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            String searchProduct = this.id.getText();
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID='" + searchProduct + "'");
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6) , rs.getString(7), rs.getString(8), rs.getString(9)));
            }
            
            conn.close();
      
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
  
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.sizecolumn.setCellValueFactory(new PropertyValueFactory("size"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.locationcolumn.setCellValueFactory(new PropertyValueFactory("location"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.subcatcolumn.setCellValueFactory(new PropertyValueFactory("subcategory"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
            
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
  }
  
  
  // used only inside initialize method
  private void findProduct2(){
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            String searchProduct = this.id.getText();
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID= '" + searchProduct + "'");
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6) , rs.getString(7), rs.getString(8), rs.getString(9)));
            }
            
            conn.close();
      
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.sizecolumn.setCellValueFactory(new PropertyValueFactory("size"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.locationcolumn.setCellValueFactory(new PropertyValueFactory("location"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.subcatcolumn.setCellValueFactory(new PropertyValueFactory("subcategory"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
      
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
  }

  
  @FXML
  private void clearFields(ActionEvent event) { 
    
    this.id.setText("");   
    this.category.setValue(null);
    
    sublist = FXCollections.observableArrayList("Select category");
    this.subcategory.setItems(sublist);
    this.subcategory.setValue(null);
    this.supplier.setValue(null);
  }
  
  @FXML
  private void plusOneProduct(ActionEvent event){
      
    String sql = "UPDATE `products` SET quantity=quantity+1 WHERE productID=?";
    try {
      Connection conn = dbConnection.getConnection();
      PreparedStatement stmt = conn.prepareStatement(sql);
      stmt.setString(1, this.id.getText());
      stmt.execute();
      
      findProduct(event); // call this method to refresh product's data
                  
      // write action to log file
      ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity FROM products WHERE productID='" + this.id.getText() +"'");
      
      // checking if ResultSet is empty
      if (rs.next() == false)
            System.out.println("ResultSet is empty!");
      else{
            String Pname = rs.getString(1);
            String Psize = rs.getString(2);
            int Pqty = rs.getInt(3);

            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            ReadWriteLog logObject = new ReadWriteLog();
            logObject.logWriteFunction("Log Action: Plus ONE Item. "+"Product ID= " + this.id.getText() + ". Name= "+ Pname + ".\nSize= " + Psize + ".New QTY= " + Pqty + ".Time= " + timeStamp+ "\n");

      }
      
      conn.close();
    } catch (SQLException e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  
  }
  
    
  @FXML
  private void plusTenProduct(ActionEvent event){
    String sql = "UPDATE `products` SET quantity=quantity+10 WHERE productID=?";
    try {
      Connection conn = dbConnection.getConnection();
      PreparedStatement stmt = conn.prepareStatement(sql);
      stmt.setString(1, this.id.getText());
      stmt.execute();
      
      findProduct(event); // call this method to refresh the table's data
      
      // write action to log file
      ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity FROM products WHERE productID='" + this.id.getText()+"'");
      
      // checking if ResultSet is empty
      if (rs.next() == false)
            System.out.println("ResultSet is empty!");
      else{
            String Pname = rs.getString(1);
            String Psize = rs.getString(2);
            int Pqty = rs.getInt(3);

            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            ReadWriteLog logObject = new ReadWriteLog();
            logObject.logWriteFunction("Log Action: Plus TEN Items. "+"Product ID= " + this.id.getText() + ". Name= "+ Pname + 
                    ".\nSize= " + Psize + ".New QTY= " + Pqty + ".Time= " + timeStamp+ "\n");
      
      }
      
      conn.close();
      
    } catch (SQLException e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  
  }
  
  
  @FXML
  private void minusOneProduct(ActionEvent event){
    int qtylimit=0;
    
    // find the quantity of the product that we want to sell and so remove one iten from quantity
    try{
        Connection conn = dbConnection.getConnection();
        ResultSet rs = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID='" + this.id.getText()+"'");
        
        // checking if ResultSet is empty
        if (rs.next() == false)
            System.out.println("ResultSet is empty!");
        else 
            qtylimit = rs.getInt(1); 
        
        conn.close();
    
    } catch(SQLException e){
        System.err.println("Got an exception!");
        System.err.println(e.getMessage());
    
    }
    
    // if quantity is over zero then reduce the qty by one item
    if(qtylimit>0)  {
        
        String sql = "UPDATE `products` SET quantity=quantity-1 WHERE productID=?";
        try {
            Connection conn = dbConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());
            stmt.execute();
      
            findProduct(event); // call this method to refresh the table's data
            
            // write action to log file
            ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity FROM products WHERE productID='" + this.id.getText()+"'");
            
            // checking if ResultSet is empty
            if (rs.next() == false)
                System.out.println("ResultSet is empty!");
            else {
            
                String productname = rs.getString(1);
                String Psize = rs.getString(2);
                int Pqty = rs.getInt(3);
                String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
                ReadWriteLog logObject = new ReadWriteLog();
                logObject.logWriteFunction("Log Action: Minus ONE Item. "+"Product ID= " + this.id.getText() + ".\nName= "+ productname + ". Size= " + Psize + ". New QTY= " + Pqty+ 
                        ".\nTime= " + timeStamp + "\n");
            
            }
                
            conn.close();
      
        } catch (SQLException e) {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }
        
    }
    
  }
  
  
    @FXML
    public void loadSubcategoryItems (ActionEvent event){

        boolean isCategoryEmpty = category.getSelectionModel().isEmpty();

        //user selected item on category combobox
        if (!isCategoryEmpty){
            String tempcat = this.category.getValue(); 

            // loading the subcategories per category (tempcat)
            loadCategories ob2 = new loadCategories();
            sublist = ob2.getSubCategories(tempcat);        

            // connect combobox and list of items for sub-category combobox
            subcategory.setItems(sublist);

        }   

    }

  
  @FXML
  private void openAddProductStage(ActionEvent event){
      try {
      Stage addProductStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane addProductpane = (Pane)loader.load(getClass().getResource("/addnewproduct/addnewproductFXML.fxml").openStream());
      
      Scene addProductscene = new Scene(addProductpane);
      addProductscene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());
      
      // change the default app icon appearing on the system tray. working only for windows OS.
      Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
      addProductStage.getIcons().add(icon);
      
      addProductStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
      addProductStage.setScene(addProductscene);
      addProductStage.setTitle("Add New Product");
      addProductStage.setResizable(false);
      addProductStage.showAndWait(); //Display window and wait for it to be closed before returning
    } catch (IOException e) {
      e.printStackTrace();
      
    }
      
  }
  
    @FXML
    private void openDeleteProductStage(ActionEvent event){
      try {
      Stage addProductStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane addProductpane = (Pane)loader.load(getClass().getResource("/deleteproduct/deleteProductFXML.fxml").openStream());
      
      Scene addProductscene = new Scene(addProductpane);
      addProductscene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());
      
      // change the default app icon appearing on the system tray. working only for windows OS.
      Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
      addProductStage.getIcons().add(icon);
      
      addProductStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
      addProductStage.setScene(addProductscene);
      addProductStage.setTitle("Delete Product");
      addProductStage.setResizable(false);
      addProductStage.showAndWait(); //Display window and wait for it to be closed before returning
    } catch (IOException e) {
      e.printStackTrace();
      
    }
      
  }
  
    @FXML
     private void openUpdateProductStage(ActionEvent event){
       try {
       Stage addProductStage = new Stage();
       FXMLLoader loader = new FXMLLoader();
       Pane addProductpane = (Pane)loader.load(getClass().getResource("/updateproduct/updateProductFXML.fxml").openStream());

       Scene addProductscene = new Scene(addProductpane);
       addProductscene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());

       // change the default app icon appearing on the system tray. working only for windows OS.
       Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
       addProductStage.getIcons().add(icon);

       addProductStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
       addProductStage.setScene(addProductscene);
       addProductStage.setTitle("Update Product Info");
       addProductStage.setResizable(false);
       addProductStage.showAndWait(); //Display window and wait for it to be closed before returning
     } catch (IOException e) {
       e.printStackTrace();

     }

   }

  
}
