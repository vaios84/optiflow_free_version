
package Admin;

import alertBox.AlertBox;
import com.sun.javafx.util.Utils;
import dbUtil.dbConnection;
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import org.odftoolkit.simple.TextDocument;
import java.util.* ;
import javafx.scene.control.Label;
import org.odftoolkit.simple.text.list.List;


public class printUsersFXMLController implements Initializable {
    
    @FXML
    private Label formId;
    
    // create combobox and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> users;
    private ObservableList<String> userslist;

    @FXML
    private Button printbutton;
    @FXML
    private Button gobackbutton;
    
    private dbConnection dc;
    
    int num;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.dc = new dbConnection();   
        
        // create a 3digit, random ID in the range 1 - 999
        Random rand = new Random();
        num = rand.nextInt(998) + 1;
        
        this.formId.setText(new StringBuilder().append("Users Form ID #").append(num).toString());
        
        // connect combobox and list of items for users Combobox
        try{
              Connection conn = dbConnection.getConnection();
              this.userslist = FXCollections.observableArrayList();
              this.userslist.add("all");
              
              ResultSet rs = conn.createStatement().executeQuery("SELECT lname FROM students");
              while (rs.next()) {
                  this.userslist.add(rs.getString(1));
              }      

              users.setItems(userslist);

              conn.close();

        } catch(SQLException e){
            System.err.println("Error " + e);   
        }
        
    }
    
    
    @FXML
    public void printForms(ActionEvent event){
        
        ResultSet rs = null;
        String timeStamp = new SimpleDateFormat("yyMMdd").format(new Date());
        
        TextDocument outputOdt;
            try {
		outputOdt = TextDocument.newTextDocument();
                
                // add image
                // outputOdt.newImage(new URI("/home/vaios/NetBeansProjects/optiflow/src/img/odf-logo.png"));
                
		// add paragraph
		outputOdt.addParagraph("OPTIFLOW System\n\nDate: "+ timeStamp + "\nUsers Form ID #" + num + "\n").applyHeading(true, 5);
                
                Connection conn = dbConnection.getConnection();
                    
                boolean isUsersEmpty = users.getSelectionModel().isEmpty();
                    
                // The percent sign % wildcard matches any sequence of zero or more characters
                String temp;                    
                if (!isUsersEmpty) temp= this.users.getValue();
                else temp="%";
                    
                if (temp== "all") temp="%"; 
            
                rs = conn.createStatement().executeQuery(new StringBuilder().append("SELECT * FROM students WHERE lname LIKE '").append(temp).append("'").toString());
                    
                // add list
		outputOdt.addParagraph("----------- Users List -----------").applyHeading(true, 5);
                
                List listofItems = outputOdt.addList();
                String[] items = new String[100000];                
                Integer i=0;
                String user;
                
                while(rs.next()){
                    user = new StringBuilder().append("User: ID ").append(rs.getString(1)).append(", ").append(rs.getString(2)).append(" ").append(rs.getString(3))
                                              .append(", ").append(rs.getString(4)).append(", ").append(rs.getString(5)).append(", ").append(rs.getString(6))
                                              .append(", ").append(rs.getString(7)).append(", ").append(rs.getString(8)).append(", ").append(rs.getString(9)).toString();
                    items[i]= user;
                    ++i;
                
                }
                
		listofItems.addItems(items);
                
                // this is where curDir gets set to the absolute path of 'home/'
                String currentDir = new File("").getAbsolutePath(); 
                
                if(Utils.isWindows())
                    outputOdt.save(new StringBuilder().append(currentDir).append("\\forms\\").append(timeStamp).append("-Users-").append(num).append(".odt").toString());
                else
                    outputOdt.save(new StringBuilder().append(timeStamp).append("-Users-").append(num).append(".odt").toString());
                
                 //show the alert
                AlertBox ob1 = new AlertBox();
                ob1.showPrintFormAlert();   
                
                // clear all Fields
                clearFields();
                
                conn.close();
	
            }
            catch(SQLException e) {
                System.err.println("Error " + e);   
            }
            catch (Exception e) {
		System.err.println("ERROR: unable to create output file.");
            }
            
    
    }
    
    @FXML
    private void clearFields() { 
        
       this.dc = new dbConnection();   
        
        // create a 3digit, random ID in the range 1 - 999
        Random rand = new Random();
        num = rand.nextInt(998) + 1;
        
        this.formId.setText(new StringBuilder().append("Users Form ID #").append(num).toString());
        
        // connect combobox and list of items for users Combobox
        try{
              Connection conn = dbConnection.getConnection();
              this.userslist = FXCollections.observableArrayList();
              this.userslist.add("all");
              
              ResultSet rs = conn.createStatement().executeQuery("SELECT lname FROM students");
              while (rs.next()) {
                  this.userslist.add(rs.getString(1));
              }      

              users.setItems(userslist);

              conn.close();

        } catch(SQLException e){
            System.err.println("Error " + e);   
        }
    }

    @FXML
    public void goback(ActionEvent event) {
        Stage stage = (Stage)this.gobackbutton.getScene().getWindow();
        stage.close();    
        
    }
    
    
}
