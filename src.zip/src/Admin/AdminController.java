package Admin;

import alertBox.AlertBox;
import com.sun.javafx.util.Utils;
import dbUtil.dbConnection;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AdminController implements Initializable
{ 
    @FXML
    private TextField id;
    @FXML
    private TextField firstname;
    @FXML
    private TextField lastname;
    @FXML
    private TextField email;
    @FXML
    private TextField telephone;
    @FXML
    private DatePicker datehired;
    @FXML
    private TextField username;
    @FXML
    private TextField password;

    @FXML
    private TableView<StudentData> studenttable;
    @FXML
    private TableColumn<StudentData, String> idcolumn;
    @FXML
    private TableColumn<StudentData, String> firstnamecolumn;
    @FXML
    private TableColumn<StudentData, String> lastnamecolumn;
    @FXML
    private TableColumn<StudentData, String> emailcolumn;
    @FXML
    private TableColumn<StudentData, String> phonecolumn;
    @FXML
    private TableColumn<StudentData, String> datehiredcolumn;
    @FXML
    private TableColumn<StudentData, String> usercolumn;
    @FXML
    private TableColumn<StudentData, String> passwordcolumn; 

    @FXML
    private Button openprintbutton;
    @FXML
    private Button openFormsbutton;
    @FXML
    private Button openUpdatebutton;
    @FXML
    private Button refreshTablebutton;


    private ObservableList<StudentData> data;
    private dbConnection dc;
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {

      this.dc = new dbConnection();    

      // make a textfield automatically clicked ana ready for user input
      Platform.runLater(new Runnable() {
          @Override
          public void run() {
              id.requestFocus();
          }
      });

      loadStudentData(); // initial loading of the users data

    }
  
  
    public void loadStudentData()
    {
      try
      {
        Connection conn = dbConnection.getConnection();
        this.data = FXCollections.observableArrayList();

        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
        while (rs.next()) {
          this.data.add(new StudentData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));

        }

        conn.close();

      }
      catch (SQLException e)
      {
        System.err.println("Error " + e);
      }
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("ID"));
      this.firstnamecolumn.setCellValueFactory(new PropertyValueFactory("firstName"));
      this.lastnamecolumn.setCellValueFactory(new PropertyValueFactory("lastName"));
      this.emailcolumn.setCellValueFactory(new PropertyValueFactory("email"));
      this.phonecolumn.setCellValueFactory(new PropertyValueFactory("phone"));
      this.datehiredcolumn.setCellValueFactory(new PropertyValueFactory("datehired"));
      this.usercolumn.setCellValueFactory(new PropertyValueFactory("username"));
      this.passwordcolumn.setCellValueFactory(new PropertyValueFactory("password"));

      this.studenttable.setItems(null);
      this.studenttable.setItems(this.data);
    }
  
    @FXML
    public void refreshTableData(ActionEvent event)
    {
      try
      {
        Connection conn = dbConnection.getConnection();
        this.data = FXCollections.observableArrayList();

        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
        while (rs.next()) {
          this.data.add(new StudentData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));

        }

        conn.close();

      }
      catch (SQLException e)
      {
        System.err.println("Error " + e);
      }
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("ID"));
      this.firstnamecolumn.setCellValueFactory(new PropertyValueFactory("firstName"));
      this.lastnamecolumn.setCellValueFactory(new PropertyValueFactory("lastName"));
      this.emailcolumn.setCellValueFactory(new PropertyValueFactory("email"));
      this.phonecolumn.setCellValueFactory(new PropertyValueFactory("phone"));
      this.datehiredcolumn.setCellValueFactory(new PropertyValueFactory("datehired"));
      this.usercolumn.setCellValueFactory(new PropertyValueFactory("username"));
      this.passwordcolumn.setCellValueFactory(new PropertyValueFactory("password"));

      this.studenttable.setItems(null);
      this.studenttable.setItems(this.data);
    }

    
    @FXML
    public void addStudent(ActionEvent event)
    {
      String sql = "INSERT INTO `students`(`id`, `fname`, `lname`, `email`, `phone`, `datehired`, `username`, `password` ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
      try
      {
        Connection conn = dbConnection.getConnection();
        
        //show the alert
        AlertBox ob1 = new AlertBox();
        
        // check that no items with blank id are inserted in my db
        if( this.id.getText().trim().length()>0 && this.id.getText()!=null &&
            this.firstname.getText().trim().length()>0 && this.firstname.getText()!=null && 
            this.lastname.getText().trim().length()>0 && this.lastname.getText()!=null && 
            this.username.getText().trim().length()>0 && this.username.getText()!=null && 
            this.password.getText().trim().length()>0 && this.password.getText()!=null  ) {

              PreparedStatement stmt = conn.prepareStatement(sql);
              stmt.setString(1, this.id.getText());
              stmt.setString(2, this.firstname.getText());
              stmt.setString(3, this.lastname.getText());
              stmt.setString(4, this.email.getText());
              stmt.setString(5, this.telephone.getText());
              stmt.setString(6, this.datehired.getEditor().getText());
              stmt.setString(7, this.username.getText());
              stmt.setString(8, this.password.getText());          

              stmt.execute();
              loadStudentData(); // call this method to refresh the table's data

              //show the alert
              ob1.showGeneralAlert();

        }
        else {
            // show the alert that you must give id, firstname, lastname , username, password
            ob1.showUserInfoAlert(); 
        }

        conn.close();
      }
      catch (SQLException e)
      {
        System.err.println("Got an exception!");
        System.err.println(e.getMessage());
      }
    }
  
  
    @FXML
    public void removeStudent(ActionEvent event)
    {
      // delete protection for the two admin profiles
      String searchUser = this.id.getText().trim();
      if(searchUser.equals("10001") || searchUser.equals("10002")) return;
      
      
      AlertBox alert1 = new AlertBox();
      int reply = alert1.displayDeleteConfirmation();
      if (reply==0) return;
      
      String sql = "DELETE FROM `students` WHERE id=?";
      try
      {
          Connection conn = dbConnection.getConnection();

          // check that no items with blank id are inserted in my db
          if(this.id.getText().trim().length()>0 && this.id.getText()!=null) {

                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, this.id.getText());
                stmt.execute();

                loadStudentData(); // call this method to refresh the table's data

                //show the alert
                AlertBox ob1 = new AlertBox();
                ob1.showGeneralAlert();
          }

          conn.close();
      }
      catch (SQLException e)
      {
        System.err.println("Got an exception!");
        System.err.println(e.getMessage());
      }
    }

    @FXML
    public void clearFields(ActionEvent event)
    {
        this.id.setText("");
        this.firstname.setText("");
        this.lastname.setText("");
        this.email.setText("");
        this.telephone.setText("");
        this.datehired.setValue(null);
        this.username.setText("");
        this.password.setText("");
    }
  
  
    @FXML
    public void updateStudent(ActionEvent event) 
    {
      try {
        Stage dataStage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        Pane datapane = (Pane)loader.load(getClass().getResource("/Admin/updateUserFXML.fxml").openStream());

        Scene datascene = new Scene(datapane);
        datascene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());

        // change the default app icon appearing on the system tray. working only for windows OS.
        Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
        dataStage.getIcons().add(icon);

        dataStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
        dataStage.setScene(datascene);
        dataStage.setTitle("Update User Data");
        dataStage.setResizable(false);
        dataStage.showAndWait(); //Display window and wait for it to be closed before returning
      } catch (IOException e) {
        e.printStackTrace();

      }

    }
  
  
    @FXML
    public void printUsers(ActionEvent event) {
      try {
        Stage dataStage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        Pane datapane = (Pane)loader.load(getClass().getResource("/Admin/printUsersFXML.fxml").openStream());

        Scene datascene = new Scene(datapane);
        datascene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());

        // change the default app icon appearing on the system tray. working only for windows OS.
        Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
        dataStage.getIcons().add(icon);

        dataStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
        dataStage.setScene(datascene);
        dataStage.setTitle("Print Users");
        dataStage.setResizable(false);
        dataStage.showAndWait(); //Display window and wait for it to be closed before returning
      } catch (IOException e) {
        e.printStackTrace();

      }

    }
  
  
    @FXML
    public void browseFormsFolder(ActionEvent event) throws IOException, Exception {
        
        if(Utils.isWindows()){
            
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Doc File");
            fileChooser.setInitialDirectory(new File("forms"));
            fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Doc Files", "*.odt", "*.doc", "*.docx", "*.docm"),
            new FileChooser.ExtensionFilter("Text Files", "*.txt"),
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new FileChooser.ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                String path = selectedFile.getAbsolutePath();
                
                Desktop.getDesktop().open(new File(path));
                
                Runtime.getRuntime().exec(new String[]{"start winword ", path});
                
                //Runtime.getRuntime().exec(new String[]{"winword ", path});
                
                //Runtime.getRuntime().exec(new String[]{"start ", path});
            }
        
        } else { //Linux
        
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Doc File");
            //fileChooser.setInitialDirectory(new File("forms"));
            fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Doc Files", "*.odt", "*.doc", "*.docx", "*.docm"),
            new FileChooser.ExtensionFilter("Text Files", "*.txt"),
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new FileChooser.ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                String path = selectedFile.getAbsolutePath();
                Runtime.getRuntime().exec(new String[]{"libreoffice",path});
            }
            
        }
        
    }
    
  
    
}
