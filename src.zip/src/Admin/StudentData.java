package Admin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class StudentData
{
  private final StringProperty ID;
  private final StringProperty firstName;
  private final StringProperty lastName;
  private final StringProperty email;
  private final StringProperty phone;
  private final StringProperty datehired;
  private final StringProperty username;
  private final StringProperty password;
  
  public StudentData(String id, String firstname, String lastname, String email, String phone, String datehired,  String username, String password)
  {
    this.ID = new SimpleStringProperty(id);
    this.firstName = new SimpleStringProperty(firstname);
    this.lastName = new SimpleStringProperty(lastname);
    this.email = new SimpleStringProperty(email);
    this.phone = new SimpleStringProperty(phone);
    this.datehired = new SimpleStringProperty(datehired);
    this.username = new SimpleStringProperty(username);
    this.password = new SimpleStringProperty(password);
    
  }
  
  public String getID()
  {
    return (String)this.ID.get();
  }
  
  public String getFirstName()
  {
    return (String)this.firstName.get();
  }
  
  public String getLastName()
  {
    return (String)this.lastName.get();
  }
  
  public String getEmail()
  {
    return (String)this.email.get();
  }
    
   public String getPhone()
  {
    return (String)this.phone.get();
  }
  
  public String getDatehired()
  {
    return (String)this.datehired.get();
  } 
  
   public String getUsername()
  {
    return (String)this.username.get();
  }
  
  public String getPassword()
  {
    return (String)this.password.get();
  }
  
  
  public void setID(String value)
  {
    this.ID.set(value);
  }
  
  public void setFirstName(String value)
  {
    this.firstName.set(value);
  }
  
  public void setLastName(String value)
  {
    this.lastName.set(value);
  }
  
  public void setEmail(String value)
  {
    this.email.set(value);
  }
    
  public void setPhone(String value)
  {
    this.phone.set(value);
  }
  
  public void setDatehired(String value)
  {
    this.datehired.set(value);
  }
  
  public void setUsername(String value)
  {
    this.username.set(value);
  }
  
  public void setPassword(String value)
  {
    this.password.set(value);
  }
  
  public StringProperty idProperty()
  {
    return this.ID;
  }
  
  public StringProperty firstNameProperty()
  {
    return this.firstName;
  }
  
  public StringProperty lastNameProperty()
  {
    return this.lastName;
  }
  
  public StringProperty emailProperty()
  {
    return this.email;
  }
  
  public StringProperty phoneProperty()
  {
    return this.phone;
  }

  public StringProperty datehiredProperty()
  {
    return this.datehired;
  }

    public StringProperty usernameProperty()
  {
    return this.username;
  }

  public StringProperty passwordProperty()
  {
    return this.password;
  }
  
  
}
