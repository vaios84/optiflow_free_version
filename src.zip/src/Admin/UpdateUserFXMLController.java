
package Admin;

import alertBox.AlertBox;
import dbUtil.dbConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UpdateUserFXMLController implements Initializable {
    //buttons
    @FXML
    private Button findbutton;
    @FXML
    private Button updatebutton;
    @FXML
    private Button gobackbutton;
    
    // data input fields
    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField lastname;
    @FXML
    private TextField email;
    @FXML
    private TextField telephone;
    @FXML
    private TextField datehired;
    @FXML
    private TextField username;
    @FXML
    private TextField password;
    
    private ObservableList<StudentData> data;
    
    private static boolean userFound;
    
    //connection object
    private dbConnection dc;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        this.dc = new dbConnection(); 
        userFound = false;
        loadStudentData(); // initial loading of the users data
        
    }
    
    private void loadStudentData() {
        try
        {
          Connection conn = dbConnection.getConnection();
          this.data = FXCollections.observableArrayList();

          ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
          while (rs.next())
                this.data.add(new StudentData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));

          conn.close();
        }
        catch (SQLException e)
        {
          System.err.println("Error " + e);
        }

    }
    
    
    @FXML
    private void findUser(ActionEvent event) {
        try{
            Connection conn = dbConnection.getConnection();            
            
            String searchUser = this.id.getText();
            
            // make some textfields of the admin profiles not editable (so update only some info for the admin)
            if(searchUser.trim().equals("10001") || searchUser.trim().equals("10002")) {
                this.id.setEditable(false);
                this.name.setEditable(false);
                this.lastname.setEditable(false);
                this.username.setEditable(false);
            }
            
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students WHERE id= '" + searchUser + "'");
            
            this.id.setText(rs.getString(1));
            this.name.setText(rs.getString(2));
            this.lastname.setText(rs.getString(3));       
            this.email.setText(rs.getString(4));
            this.telephone.setText(rs.getString(5));
            this.datehired.setText(rs.getString(6));
            this.username.setText(rs.getString(7));
            this.password.setText(rs.getString(8));
            
            userFound = true;
                   
            conn.close();
      
        } catch(SQLException e){
          System.err.println("Error " + e);   
        }

    }
    
    
    
    @FXML
    private void updateUserData(ActionEvent event) 
    {   
        // protection for the case the user enters only id and hits update button (without first calling findUser). 
        // If this didnt exist all blank textfields whould be stored and delete all data.
        if(!userFound) return;
        
        String tempName = this.name.getText();
        String tempLname = this.lastname.getText();
        String tempEmail = this.email.getText();
        String tempPhone = this.telephone.getText();
        String tempdatehired = this.datehired.getText();
        String tempUser = this.username.getText();
        String tempPW = this.password.getText();
       
        String sql = "UPDATE `students` SET fname ='" + tempName + "'," +
                                            "lname = '" + tempLname + "'," +
                                            "email = '" + tempEmail + "'," +
                                            "phone = '" + tempPhone + "'," +
                                            "datehired = '" + tempdatehired + "'," +
                                            "username = '" + tempUser + "'," +
                                            "password = '" + tempPW + "'" +
                                            " WHERE id=?";
        try {
            
            //create an object to show alerts
            AlertBox ob1 = new AlertBox();
            
            if( this.id.getText().trim().length()>0 && this.id.getText()!=null &&
                this.name.getText().trim().length()>0 && this.name.getText()!=null && 
                this.lastname.getText().trim().length()>0 && this.lastname.getText()!=null && 
                this.username.getText().trim().length()>0 && this.username.getText()!=null && 
                this.password.getText().trim().length()>0 && this.password.getText()!=null ) {

                Connection conn = dbConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, this.id.getText());
                stmt.execute();

                //show the alert
                ob1.showGeneralAlert();
                
                loadStudentData(); // refresh data after the update action
                
                userFound = false;

                conn.close(); 

            }
            else {
                 // show the alert that you must give id, firstname, lastname , username, password
                ob1.showUserInfoAlert(); 
                
            }
        } catch (SQLException e) {
          System.err.println("Got an exception!");
          System.err.println(e.getMessage());
        }

    }
  
    @FXML
    public void goback(ActionEvent event) {
        Stage stage = (Stage)this.gobackbutton.getScene().getWindow();
        stage.close();    
        
    }

}
