package loginapp;

import Admin.AdminController;
import AdminPanel.AdminPanelFXMLController;
import alertBox.AlertBox;
import dbUtil.freeVersionLimitations;
import students.StudentsFXMLController;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import readWriteLog.ReadWriteLog;

public class LoginMainController implements Initializable
{
    
    LoginModel loginModel = new LoginModel();
    @FXML
    private Label dbstatus;
    @FXML
    private Button loginButton;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private ComboBox<option> combobox;
    @FXML
    private Label loginstatus;
    
    // the systems mac address
    private String macString;
    // the valid mac addresses list
    private ArrayList<String> macList = new ArrayList<>();
    
    public void initialize(URL url, ResourceBundle rb) {
      // in the free version I set the text for the Label dbstatus in loginmain.fxml
      /*
      if (this.loginModel.isDatabaseConnected()) {
        this.dbstatus.setText("Connected to Database"); 
      } else {
        this.dbstatus.setText("Not Connected to Database");
      }
      */
      
      this.combobox.setItems(FXCollections.observableArrayList(option.values()));
      
    }

    @FXML
    public void Login(ActionEvent event) throws IOException
    {
        // check the free version limitations
        boolean withinLimits=false, withinLimits2=false;
        
        freeVersionLimitations limitationsObject = new freeVersionLimitations();
        
        limitationsObject.checkTheSystemsClock();
        withinLimits = limitationsObject.checkProductsNumber();
        withinLimits2 = limitationsObject.checkSalesNumber();
        
        //create object of class AlertBox 
        AlertBox alertOb = new AlertBox();
        
        if (!withinLimits || !withinLimits2) {
        
            alertOb.showfreeVersionLimitsError();
            
            try {
                Thread.sleep(5000);
            }
            catch (InterruptedException e2) {
                // log the exception
                System.err.println("System Mac Exp : " + e2.getMessage());
            }
            
            System.exit(0);
        
        
        }
        
        try
        {
                if (this.loginModel.isLogin(this.username.getText(), this.password.getText(), ((option)this.combobox.getValue()).toString()))
                {
                        Stage stage = (Stage)this.loginButton.getScene().getWindow();
                        stage.close();

                        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
                        ReadWriteLog logObject = new ReadWriteLog();

                        switch (((option)this.combobox.getValue()).toString())
                        {
                            case "Admin": 
                              logObject.logWriteFunction("#####################" + System.lineSeparator() +"Admin Login: "+ this.username.getText() + ". Timestamp= " + timeStamp + System.lineSeparator());
                              adminPanelLogin();
                              break;
                            case "User": 
                              logObject.logWriteFunction("#####################"+ System.lineSeparator() +"User Login: "+ this.username.getText() + ". Timestamp= " + timeStamp + System.lineSeparator());
                              studentLogin();
                              break;
                            default:
                              System.out.println("Login Error.");
                              break;
                        }
                }
                else
                {
                    this.loginstatus.setText("Wrong Credentials");
                }
        }
        catch (Exception localException) {
                localException.printStackTrace();
                System.out.println("Error. localException");
        }
        
    }

    // when a user is calling this function
    public void studentLogin()
    {
        try
        {
            Stage userStage = new Stage();
            FXMLLoader loader = new FXMLLoader();
            Pane studentroot = (Pane)loader.load(getClass().getResource("/students/StudentsFXML.fxml").openStream());
            StudentsFXMLController studentController = (StudentsFXMLController)loader.getController();

            Scene studentscene = new Scene(studentroot);
            studentscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());

            // change the default app icon appearing on the system tray. working only for windows OS.
            Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
            userStage.getIcons().add(icon);

            userStage.initModality(Modality.NONE);
            //userStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows, but deletes the minimize button and functionality
            userStage.setScene(studentscene);
            userStage.setTitle("OPTIFLOW v1.0 | User: " + this.username.getText());

            userStage.setResizable(true);
            userStage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }   
    }

    // when the admin is calling this function
    public void studentLogin2()
    {
      try
      {
        Stage userStage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        Pane studentroot = (Pane)loader.load(getClass().getResource("/students/StudentsFXML.fxml").openStream());
        StudentsFXMLController studentController = (StudentsFXMLController)loader.getController();

        Scene studentscene = new Scene(studentroot);
        studentscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());
        
        // change the default app icon appearing on the system tray. working only for windows OS.
        Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
        userStage.getIcons().add(icon);

        userStage.initModality(Modality.NONE);
        //userStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows, but deletes the minimize button and functionality
        userStage.setScene(studentscene);
        userStage.setTitle("OPTIFLOW v1.0 | ADMIN ");

        userStage.setResizable(true);
        userStage.show();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }


    public void adminLogin()
    {
      try
      {
        Stage adminStage = new Stage();
        FXMLLoader adminLoader = new FXMLLoader();
        Pane adminroot = (Pane)adminLoader.load(getClass().getResource("/Admin/Admin.fxml").openStream());
        AdminController adminController = (AdminController)adminLoader.getController();

        Scene adminscene = new Scene(adminroot);
        adminscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());
        
        // change the default app icon appearing on the system tray. Working only for windows OS.
        Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
        adminStage.getIcons().add(icon);

        adminStage.initModality(Modality.NONE); 
        //adminStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows, but deletes the minimize button and functionality
        adminStage.setScene(adminscene);
        adminStage.setTitle("OPTIFLOW v1.0");
        adminStage.setResizable(true); 
        adminStage.show();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }

    public void adminPanelLogin()
    {
      try
      {
        Stage adminPanelStage = new Stage();
        FXMLLoader adminLoader = new FXMLLoader();
        Pane adminpanelroot = (Pane)adminLoader.load(getClass().getResource("/AdminPanel/AdminPanelFXML.fxml").openStream());
        AdminPanelFXMLController adminPanelController = (AdminPanelFXMLController)adminLoader.getController();

        Scene adminscene = new Scene(adminpanelroot);
        adminscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());
        
        // change the default app icon appearing on the system tray. Working only for windows OS.
        Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
        adminPanelStage.getIcons().add(icon);

        adminPanelStage.initModality(Modality.NONE);  
        //adminPanelStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows, but deletes the minimize button and functionality
        adminPanelStage.setScene(adminscene);
        adminPanelStage.setTitle("OPTIFLOW v1.0 ");
        adminPanelStage.setResizable(false); 
        adminPanelStage.show();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }  

}
