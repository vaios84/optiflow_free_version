package loginapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class LoginApp extends Application
{
    
  @Override
  public void start(Stage stage) throws Exception
  {
    Parent root = (Parent)FXMLLoader.load(getClass().getResource("LoginMain.fxml"));
    
    Scene scene = new Scene(root);
    // change the default app icon appearing on the system tray. working only for windows OS.
    Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
    stage.getIcons().add(icon);
    
    stage.setScene(scene);
    stage.setTitle("OPTIFLOW v1.0 ");
    stage.setResizable(false);
    stage.show();
  }
  
  public static void main(String[] args)
  {
    launch(args);
  }
}