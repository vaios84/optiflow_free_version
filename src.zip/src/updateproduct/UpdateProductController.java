
package updateproduct;

import alertBox.AlertBox;
import dbUtil.dbConnection;
import dbUtil.loadCategories;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import readWriteLog.ReadWriteLog;
import students.ProductData;

public class UpdateProductController implements Initializable {
    
    @FXML
    private TextField id;
    @FXML
    private TextField pname;
    @FXML
    private TextField size;  
    @FXML
    private TextField qty;
    @FXML
    private TextField location;

    // create combobox category and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> category;
    private ObservableList<String> list = FXCollections.observableArrayList();
    
    // create combobox sub-category and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> subcategory;
    private ObservableList<String> sublist = FXCollections.observableArrayList("Select category");
    
    @FXML
    private TextField price;

    // create combobox and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> supplier;
    private ObservableList<String> supplierlist;

    @FXML
    private Button findbutton;    
    @FXML
    private Button updatebutton;
    @FXML
    private Button cancelbutton;
    
    private ObservableList<ProductData> data;  
    private dbConnection dc;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
      
      this.dc = new dbConnection();
      
      // populating the list with the categories from the sql database
      loadCategories ob1 = new loadCategories();
      list = ob1.getCategories();
      
      // connect combobox and list of items for category combobox
      category.setItems(list);
      
      // connect combobox and list of items for sub-category combobox
      subcategory.setItems(sublist);
      
      
      // connect combobox and list of items for Suppliers Combobox
      try{
            Connection conn = dbConnection.getConnection();
            this.supplierlist = FXCollections.observableArrayList();
            
            ResultSet rs2 = conn.createStatement().executeQuery("SELECT company FROM suppliers");
            while (rs2.next()) {
                this.supplierlist.add(rs2.getString(1));
            }      
            supplier.setItems(supplierlist);
            
            conn.close();
            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      // make a textfield automatically clicked with cursor and ready for user input
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
            id.requestFocus();
            }
        }); 
        
        
        // product id typing or scanning and listen for ENTER key, then find the product
        // barcode scanners provide automatically a barcode ID and ENTER key
        id.setOnKeyPressed(new EventHandler<KeyEvent>() { 
            @Override
            public void handle(KeyEvent ke)
            {   
                        
                if (ke.getCode().equals(KeyCode.ENTER))
                {
                findProduct2();
               
                }
            }
        });
        
        
    }
    
    
    @FXML
    private void findProduct(ActionEvent event)
    {
        try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            String searchProduct = this.id.getText();
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID= '" + searchProduct + "'");
            
            // checking if ResultSet is empty
            if (rs.next() == false)
                System.out.println("ResultSet is empty!");
            else {
            
                this.id.setText(rs.getString(1));
                this.pname.setText(rs.getString(2));
                this.size.setText(rs.getString(3));       
                this.qty.setText(rs.getString(4));
                this.location.setText(rs.getString(5));
                this.category.setValue(rs.getString(6));
                this.subcategory.setValue(rs.getString(7));
                this.price.setText(rs.getString(8));
                this.supplier.setValue(rs.getString(9));
                
                // protect the product id from changing/update
                this.id.setEditable(false);
                
            }
            
            conn.close();
      
        } catch(SQLException e){
          System.err.println("Error " + e);   
        }

    }
    
    
    private void findProduct2()
    {
        try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            String searchProduct = this.id.getText();
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID= '" + searchProduct + "'");
            
            // checking if ResultSet is empty
            if (rs.next() == false)
                System.out.println("ResultSet is empty!");
            else {
            
                this.id.setText(rs.getString(1));
                this.pname.setText(rs.getString(2));
                this.size.setText(rs.getString(3));       
                this.qty.setText(rs.getString(4));
                this.location.setText(rs.getString(5));
                this.category.setValue(rs.getString(6));
                this.subcategory.setValue(rs.getString(7));
                this.price.setText(rs.getString(8));
                this.supplier.setValue(rs.getString(9));

                // protect the product id from changing/update
                this.id.setEditable(false);

            }
             
            conn.close();
      
        } catch(SQLException e){
          System.err.println("Error " + e);   
        }

    }
    
    
    @FXML
    public void loadSubcategoryItems (ActionEvent event){

        boolean isCategoryEmpty = category.getSelectionModel().isEmpty();

        //user selected item on category combobox
        if (!isCategoryEmpty){
            String tempcat = this.category.getValue(); 

            // loading the subcategories per category (tempcat)
            loadCategories ob2 = new loadCategories();
            sublist = ob2.getSubCategories(tempcat);        

            // connect combobox and list of items for sub-category combobox
            subcategory.setItems(sublist);

        }   

    }


    
    @FXML
    private void updateProduct(ActionEvent event)
    {
        String tempName = this.pname.getText();
        String tempsize = this.size.getText();
        String tempqty = this.qty.getText();
        String temploc = this.location.getText();
        String tempcategory = this.category.getValue();
        String tempsubcategory = this.subcategory.getValue();
        String tempprice = this.price.getText();
        String tempsupplier = this.supplier.getValue();
                
        String sql = "UPDATE `products` SET productName ='" + tempName + "'," +
                                            "size = '" + tempsize + "'," +
                                            "quantity = '" + tempqty + "'," +
                                            "location = '" + temploc + "'," +
                                            "category = '" + tempcategory + "'," +
                                            "subcategory = '" + tempsubcategory + "'," +
                                            "price = '" + tempprice + "'," +
                                            "supplier = '" + tempsupplier + "'" +
                                            " WHERE productID=?";
        try {
            Connection conn = dbConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            AlertBox ob1 = new AlertBox();
            
            

            // check if the id is empty , null or full of spaces
            if ( this.id.getText()!=null && this.id.getText().trim().length()>0 && 
                 this.pname.getText()!=null && this.pname.getText().trim().length()>0 && 
                 this.qty.getText()!=null && this.qty.getText().trim().length()>0 && 
                 this.category.getValue()!= null && this.subcategory.getValue()!= null && 
                 this.supplier.getValue()!= null ) {
                
                
                  stmt.setString(1, this.id.getText());
                  stmt.execute();

                  // write action to log file
                  ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity FROM products WHERE productID= '" + this.id.getText() + "'");
                  
                    // checking if ResultSet is empty
                    if (rs.next() == false)
                        System.out.println("ResultSet is empty!");
                    else{
                        String Pname = rs.getString(1);
                        String Psize = rs.getString(2);
                        int Pqty = rs.getInt(3);

                        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

                        ReadWriteLog logObject = new ReadWriteLog();
                        logObject.logWriteFunction("Log Action: Update. "+"Product ID= " + this.id.getText() + ". Name= "+ Pname + ".\nSize= " + Psize + ".QTY= " + Pqty + ".Time= " + timeStamp+ "\n");

                    }

                    //show the alert
                    ob1.showUpdateAlert();  

            }
            else 
            { ob1.showProductInfoAlert(); }

            conn.close();
          
        } catch (SQLException e) {
          System.err.println("Got an exception!");
          System.err.println(e.getMessage());
        }

    
    }
    
    @FXML
    private void goback(ActionEvent event) {
        Stage stage = (Stage)this.cancelbutton.getScene().getWindow();
        stage.close();    
        
    }
    
   
    @FXML
    private void clearFields(ActionEvent event) { 
    
    this.id.setText("");
    this.pname.setText("");
    this.size.setText("");
    this.qty.setText("");
    this.location.setText("");
    this.category.setValue(null);
    
    sublist = FXCollections.observableArrayList("Select category");
    this.subcategory.setItems(sublist);
    this.subcategory.setValue(null);
    this.price.setText("");
    this.supplier.setValue(null);
    
  }
    
    
    
}
