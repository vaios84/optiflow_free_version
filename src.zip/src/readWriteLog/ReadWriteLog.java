/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readWriteLog;

import com.sun.javafx.util.Utils;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import students.StudentsFXMLController;

/**
 *
 * @author vaios stergiopoulos
 */
public class ReadWriteLog {
    
        // default constructor
        public ReadWriteLog() { }
        
        // this function will be used, inside other functions of other classes, to log the actions done on the database (insert, update, delete)
        public void logWriteFunction(String mydata) {
             BufferedWriter bw = null;
             // currentDir will hold the absolute path to 'home\'
             String currentDir;
             String timeStamp = new SimpleDateFormat("yyMMdd").format(new Date());

             try {
                 
                 if(Utils.isWindows()){
                     // this is where curDir gets set to the absolute path of 'home/'
                    currentDir = new File("").getAbsolutePath(); 
                    
                    // filePath is set to 'home\docs\READTHIS.txt'
                    String filePath = new StringBuilder().append(currentDir).append("\\log\\").append(timeStamp).append("-log.txt").toString();
                    
                    bw = new BufferedWriter(new FileWriter(new File(filePath), true)); // true word here for append, not write from the beginning
                
                 }
                 else{ //linux
                     bw = new BufferedWriter(new FileWriter(new File(new StringBuilder().append(timeStamp).append("-log.txt").toString()), true)); // true word here for append, not write from the beginning
                 }
                 
                 bw.write(mydata);
                 bw.append(System.lineSeparator()); // instead of newline character (notepad can't read the newline character and shows everything in one line)
             } 
             catch (FileNotFoundException exx) {
                 exx.printStackTrace();

             }   
             catch (IOException ex) {
                  Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
             }

              try {
                  bw.close();
              } catch (IOException ex) {
                  Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
              }

        }

        
        public void logReadFunction(ActionEvent event) {
            
            // currentDir will hold the absolute path to 'home\'
            String currentDir;
            
            String timeStamp = new SimpleDateFormat("yyMMdd").format(new Date());

            try {

                if(Utils.isWindows()){
                    
                    // this is where curDir gets set to the absolute path of 'home/'
                    currentDir = new File("").getAbsolutePath();
                    
                    Runtime rt = Runtime.getRuntime();

                    // filePath set
                    String filePath = new StringBuilder().append(currentDir).append("\\log\\").append(timeStamp).append("-log.txt").toString();

                    try {
                        Process p = rt.exec("notepad " + filePath);
                    } catch (IOException ex) {
                        Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    //second way to read txt files
                    //ProcessBuilder pb1 = new ProcessBuilder("notepad.exe", new StringBuilder().append("C:\\optiflow-log\\").append(timeStamp).append("-log.txt").toString());
                    //pb1.start();
                
                } 
                else // linux
                {
                    ProcessBuilder pb2 = new ProcessBuilder("gedit", new StringBuilder().append(timeStamp).append("-log.txt").toString());
                    pb2.start();
                }

            } catch (IOException ex) {
                Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    
    
}
