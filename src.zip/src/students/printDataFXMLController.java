
package students;

import alertBox.AlertBox;
import com.sun.javafx.util.Utils;
import dbUtil.dbConnection;
import dbUtil.loadCategories;
import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import org.odftoolkit.simple.TextDocument;
import java.util.* ;
import javafx.scene.control.Label;
import org.odftoolkit.simple.text.list.List;


public class printDataFXMLController implements Initializable {
    
    @FXML
    private Label formId;
    
    // create combobox quantity and a list to connect it later inside initialize function
    @FXML
    private ComboBox<Integer> quantity;
    private ObservableList<Integer> qtylist = FXCollections.observableArrayList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50);

    
    // create combobox category and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> category;
    private ObservableList<String> list = FXCollections.observableArrayList();

    // create combobox sub-category and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> subcategory;
    private ObservableList<String> sublist = FXCollections.observableArrayList("Select category");
    
    // create combobox and a list to connect it later inside initialize function
    @FXML
    private ComboBox<String> supplier;
    private ObservableList<String> supplierlist;

    @FXML
    private Button printbutton;
    @FXML
    private Button gobackbutton;
    @FXML
    private Button clearbutton;
    
    private ObservableList<ProductData> data;  
    private dbConnection dc;
    
    int num;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.dc = new dbConnection();   
        
        // create a 3digit, random ID in the range 1 - 999
        Random rand = new Random();
        num = rand.nextInt(998) + 1;
        
        this.formId.setText(new StringBuilder().append("Products Form ID #").append(num).toString());
        
        // connect combobox and list of items for quantity combobox
        quantity.setItems(qtylist);
        
         // populating the list with the categories from the sql database
        loadCategories ob1 = new loadCategories();
        list = ob1.getCategories();
        
        // connect combobox and list of items for category combobox
        category.setItems(list);

        // connect combobox and list of items for sub-category combobox
        subcategory.setItems(sublist);

        // connect combobox and list of items for Suppliers Combobox
        try{
              Connection conn = dbConnection.getConnection();
              this.supplierlist = FXCollections.observableArrayList();

              ResultSet rs2 = conn.createStatement().executeQuery("SELECT company FROM suppliers");
              while (rs2.next()) {
                  this.supplierlist.add(rs2.getString(1));
              }      

              supplier.setItems(supplierlist);
              
              rs2.close();
              conn.close();

        } catch(SQLException e){
            System.err.println("Error " + e);   
        }
        
    }
  
    
    @FXML
    public void loadSubcategoryItems (ActionEvent event){

        boolean isCategoryEmpty = category.getSelectionModel().isEmpty();

        //user selected item on category combobox
        if (!isCategoryEmpty){
            String tempcat = this.category.getValue(); 

            // loading the subcategories per category (tempcat)
            loadCategories ob2 = new loadCategories();
            sublist = ob2.getSubCategories(tempcat);        

            // connect combobox and list of items for sub-category combobox
            subcategory.setItems(sublist);

        }   

    }

    
    @FXML
    public void printForms(ActionEvent event){
        
        ResultSet rs = null;
        String timeStamp = new SimpleDateFormat("yyMMdd").format(new Date());
        String qtyFilter = null, catFilter = null, subcatFilter = null, supFilter = null;
        
        TextDocument outputOdt;
            try {
		outputOdt = TextDocument.newTextDocument();
                
                // add image
                //outputOdt.newImage(new URI("/home/vaios/NetBeansProjects/optiflow/src/img/odf-logo.png"));
                
		// add paragraph
		outputOdt.addParagraph("OPTIFLOW System\n\nDate: "+ timeStamp + "\nProducts Form ID #" + num + "\n").applyHeading(true, 5);
                
                Connection conn = dbConnection.getConnection();
                    
                boolean isQuantityEmpty = quantity.getSelectionModel().isEmpty();
                boolean isCategoryEmpty = category.getSelectionModel().isEmpty();  
                boolean isSubcategoryEmpty = subcategory.getSelectionModel().isEmpty();
                boolean isSupplierEmpty = supplier.getSelectionModel().isEmpty();
                    
                // read users choices on the four comboboxes
                Integer temp1=1000000;
                if (!isQuantityEmpty) {
                        temp1= this.quantity.getValue();
                        qtyFilter = "Quantity <=" + temp1;
                        
                } else qtyFilter = "Quantity: All";
                    
                // The percent sign % wildcard matches any sequence of zero or more characters
                String temp2="%", temp3="%", temp4="%";
                    
                if (!isCategoryEmpty) {
                        temp2= new StringBuilder().append(this.category.getValue()).append("%").toString();
                        catFilter = "Category: " + this.category.getValue();
                    
                    }else catFilter = "Category: All";
                    
                if (!isSubcategoryEmpty) {
                        temp3  = new StringBuilder().append(this.subcategory.getValue()).append("%").toString();
                        subcatFilter = "Sub-category: "+ this.subcategory.getValue();
                    
                    } else subcatFilter = "Sub-category: All";
                    
                if (!isSupplierEmpty) { 
                        temp4 = new StringBuilder().append(this.supplier.getValue()).append("%").toString();
                        supFilter = "Supplier: " + this.supplier.getValue();
                    } else supFilter = "Supplier: All";
                    
                rs = conn.createStatement().executeQuery(new StringBuilder().append("SELECT productID, productName, size, supplier FROM products WHERE quantity <=")
                            .append(temp1).append(" AND category LIKE '").append(temp2).append("' AND subcategory LIKE '").append(temp3)
                            .append("' AND supplier LIKE '").append(temp4).append("'").toString());    
                    
                
                // print the filters applied
                outputOdt.addParagraph("----------- Products Filters -----------").applyHeading(true, 5);
                outputOdt.addParagraph(qtyFilter + "\n"+ catFilter + "\n" + subcatFilter + "\n" + supFilter);
                // add list
		outputOdt.addParagraph("----------- Products List -----------").applyHeading(true, 5);
                
                List listofItems = outputOdt.addList();
                String[] items = new String[100000];                
                Integer i=0;
                String order;
                
                if (rs.next() == false) {
                    System.out.println("ResultSet is empty!");
                } else {

                    do {

                        order = new StringBuilder().append("ID: ").append(rs.getString(1)).append(", Product: ").append(rs.getString(2)).append(", Size: ").append(rs.getString(3)).append(", Supplier: ").append(rs.getString(4)).toString();
                        items[i]= order;
                        ++i;
                    
                    } while (rs.next());
                }

		listofItems.addItems(items);
                
                // this is where curDir gets set to the absolute path of 'home/'
                String currentDir = new File("").getAbsolutePath();
                
                if(Utils.isWindows())
                    outputOdt.save(new StringBuilder().append(currentDir).append("\\forms\\").append(timeStamp).append("-Products-").append(num).append(".odt").toString());
                else
                    outputOdt.save(new StringBuilder().append(timeStamp).append("-Products-").append(num).append(".odt").toString());
                
                 //show the alert
                AlertBox ob1 = new AlertBox();
                ob1.showPrintFormAlert();
                
                // clear all Fields
                clearFields(event);
                
                rs.close();
                conn.close();
            }
            catch(SQLException e) {
                System.err.println("Error " + e);   
            }
            catch (Exception e) {
		System.err.println("Error: unable to create output file.");
            }
            
    }
    
     @FXML
    private void clearFields(ActionEvent event) { 
    
        this.quantity.setValue(null);
        this.category.setValue(null);
        
        sublist = FXCollections.observableArrayList("Select category");
        this.subcategory.setItems(sublist);
        this.subcategory.setValue(null);
               
        this.supplier.setValue(null);
        
        this.dc = new dbConnection();   
        
        // create a 3digit, random ID in the range 1 - 999
        Random rand = new Random();
        num = rand.nextInt(998) + 1;
        
        this.formId.setText(new StringBuilder().append("Products Form ID #").append(num).toString());
    
  }

    @FXML
    public void goback(ActionEvent event) {
        Stage stage = (Stage)this.gobackbutton.getScene().getWindow();
        stage.close();    
        
    }
    
    
}
