package students;

import alertBox.AlertBox;
import com.sun.javafx.util.Utils;
import dbUtil.dbConnection;
import dbUtil.freeVersionLimitations;
import dbUtil.loadCategories;
import inventorymanagement.InventoryFXMLcontroller;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import javafx.fxml.FXML;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
import readWriteLog.ReadWriteLog;
import settings.SettingsController;

public class StudentsFXMLController implements Initializable {
  
  @FXML
  private TextField id;
  @FXML
  private TextField pname;
  @FXML
  private TextField size;  
  @FXML
  private TextField qty;
  @FXML
  private TextField location;
  
  // create combobox quantity and a list to connect it later inside initialize function
  @FXML
  private ComboBox<Integer> quantity;
  private final ObservableList<Integer> qtylist = FXCollections.observableArrayList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50);
  
  // create combobox category and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> category;
  private ObservableList<String> list = FXCollections.observableArrayList();
  
  // create combobox sub-category and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> subcategory;
  private ObservableList<String> sublist = FXCollections.observableArrayList("Select category");
    
  @FXML
  private TextField price;
  
  // create combobox and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> supplier;
  private ObservableList<String> supplierlist;
  
  @FXML
  private TableView<ProductData> producttable;
  @FXML
  private TableColumn<ProductData, String> idcolumn;
  @FXML
  private TableColumn<ProductData, String> pnamecolumn;
  @FXML
  private TableColumn<ProductData, String> sizecolumn;
  @FXML
  private TableColumn<ProductData, Integer> qtycolumn;    
  @FXML
  private TableColumn<ProductData, String> locationcolumn;
  @FXML
  private TableColumn<ProductData, String> catcolumn;
  @FXML
  private TableColumn<ProductData, String> subcatcolumn;
  @FXML
  private TableColumn<ProductData, Double> pricecolumn;
  @FXML
  private TableColumn<ProductData, String> scolumn;
  
  @FXML
  private Button savebutton;
  @FXML
  private Button loadbutton;
  @FXML
  private Button clearbutton;
  @FXML
  private Button inventorybutton;
  @FXML
  private Button printbutton;
  @FXML
  private Button browsebutton1;
  @FXML
  private Button logreadbutton;
  @FXML
  private Button browsebutton2;
  
  private ObservableList<ProductData> data;  
  private dbConnection dc;
  
  private static ObservableList<String> sellingProducts = FXCollections.observableArrayList();
  
  public static boolean flagAlertBox=true; // used to call checkProductsLimits method amd show alerts for low qty once, when the appllication starts
  
  @Override
  public void initialize(URL url, ResourceBundle rb) {
      this.dc = new dbConnection();
      
      // connect combobox and list of items for quantity combobox
      quantity.setItems(qtylist);
      
      // populating the list with the categories from the sql database
      loadCategories ob1 = new loadCategories();
      list = ob1.getCategories();
      
      // connect combobox and list of items for category combobox
      category.setItems(list);
      
      // connect combobox and list of items for sub-category combobox
      subcategory.setItems(sublist);
      
      // connect combobox and list of items for Suppliers Combobox
      try{
            Connection conn = dbConnection.getConnection();
            this.supplierlist = FXCollections.observableArrayList();
            
            ResultSet rs2 = conn.createStatement().executeQuery("SELECT company FROM suppliers");
            while (rs2.next()) {
                this.supplierlist.add(rs2.getString(1));
            }      
            supplier.setItems(supplierlist);
            
            rs2.close();
            conn.close();
            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      // call loadProductData2 in order the app to load the data for the first time (but not show them in the table) 
      // now the app is able to scan (and find) a product 
      loadProductData2();
      

      
      // make a textfield (id) automatically clicked with cursor and ready for user (or barcode scanner) input
      Platform.runLater(new Runnable() {
        @Override
        public void run() {
            id.requestFocus();
        }
      });
    
      // product id typing or scanning and listen for ENTER key, then sell a product
      // barcode scanners provide automatically a barcode ID and ENTER key
      id.setOnKeyPressed(new EventHandler<KeyEvent>()
      {
        @Override
        public void handle(KeyEvent ke)
        {   
                        
            if (ke.getCode().equals(KeyCode.ENTER))
            {
               minusOneProduct2();
               findProduct2();
               clearFields2();
               
            }
        }
      });
      
    
  }
  
  @FXML
  public void saveMethod(ActionEvent event) {
      
        // check the free version limitations
        boolean withinLimits=false, withinLimits2=false;
        
        freeVersionLimitations limitationsObject = new freeVersionLimitations();
        
        limitationsObject.checkTheSystemsClock();
        withinLimits = limitationsObject.checkProductsNumber();
        withinLimits2 = limitationsObject.checkSalesNumber();
        
        //create object of class AlertBox 
        AlertBox alertOb = new AlertBox();
        
        if (!withinLimits || !withinLimits2) {
        
            alertOb.showfreeVersionLimitsError();
            
            try {
                Thread.sleep(5000);
            }
            catch (InterruptedException e2) {
                // log the exception
                System.err.println("System Mac Exp : " + e2.getMessage());
            }
            
            System.exit(0);
        
        
        }
      
      
      this.sellingProducts.clear();
      clearFields2();
      
      this.data = FXCollections.observableArrayList();
      this.data.add(new ProductData(" "," "," "," "," "," "," ", " ", " "));
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
      // make a textfield (id) automatically clicked with cursor and ready for user (or barcode scanner) input
      Platform.runLater(new Runnable() {
        @Override
        public void run() {
            id.requestFocus();
        }
      });
      
  }
  
  
  @FXML
  private void loadProductData(ActionEvent event){
      
        // check the free version limitations
        boolean withinLimits=false, withinLimits2=false;
        
        freeVersionLimitations limitationsObject = new freeVersionLimitations();
        
        limitationsObject.checkTheSystemsClock();
        withinLimits = limitationsObject.checkProductsNumber();
        withinLimits2 = limitationsObject.checkSalesNumber();
        
        //create object of class AlertBox 
        AlertBox alertOb = new AlertBox();
        
        if (!withinLimits || !withinLimits2) {
        
            alertOb.showfreeVersionLimitsError();
            
            try {
                Thread.sleep(5000);
            }
            catch (InterruptedException e2) {
                // log the exception
                System.err.println("System Mac Exp : " + e2.getMessage());
            }
            
            System.exit(0);
        
        
        }
      
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            boolean isQtyEmpty = quantity.getSelectionModel().isEmpty();
            boolean isCategoryEmpty = category.getSelectionModel().isEmpty();
            boolean isSubcategoryEmpty = subcategory.getSelectionModel().isEmpty();
            boolean isSupplierEmpty = supplier.getSelectionModel().isEmpty();
            
            // the percent sign % in sql means whetever string. example:
            // SELECT * FROM Customers WHERE CustomerName LIKE 'a%';
            
            // here we set initial values at the four variables
            String tempcat="%", tempsub="%", tempsup="%";
            int tempQty=1000000; // just a very large value of qty
            
            // read users choices in the comboboxes (only if the user has selected something)
            if (!isQtyEmpty) tempQty = this.quantity.getValue();
            if (!isCategoryEmpty) tempcat = this.category.getValue();
            if (!isCategoryEmpty && !isSubcategoryEmpty) tempsub = this.subcategory.getValue();
            if (!isSupplierEmpty) tempsup = this.supplier.getValue();
            
            ResultSet rs = conn.createStatement().executeQuery(new StringBuilder().append("SELECT * FROM products WHERE category LIKE '").append(tempcat).append("' AND subcategory LIKE '").append(tempsub).append("' AND quantity <= '").append(tempQty).append("' AND supplier LIKE '").append(tempsup).append("'").toString());
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
            }   
            
            conn.close();            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.sizecolumn.setCellValueFactory(new PropertyValueFactory("size"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.locationcolumn.setCellValueFactory(new PropertyValueFactory("location"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.subcatcolumn.setCellValueFactory(new PropertyValueFactory("subcategory"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
      
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
      //check the product qty limits , log the qty state and show alert if necessary
      if (flagAlertBox) checkProductsLimits();
      
  } 
  
   
  // loadProductData2 function to be used inside initialize function
  public void loadProductData2() {
      
        // check the free version limitations
        boolean withinLimits=false, withinLimits2=false;
        
        freeVersionLimitations limitationsObject = new freeVersionLimitations();
        
        limitationsObject.checkTheSystemsClock();
        withinLimits = limitationsObject.checkProductsNumber();
        withinLimits2 = limitationsObject.checkSalesNumber();
        
        //create object of class AlertBox 
        AlertBox alertOb = new AlertBox();
        
        if (!withinLimits || !withinLimits2) {
        
            alertOb.showfreeVersionLimitsError();
            
            try {
                Thread.sleep(5000);
            }
            catch (InterruptedException e2) {
                // log the exception
                System.err.println("System Mac Exp : " + e2.getMessage());
            }
            
            System.exit(0);
        
        
        }
      
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            ResultSet rs;
            rs = conn.createStatement().executeQuery("SELECT * FROM products");
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
            }   
            
            rs.close();
            conn.close();            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
  } 
  
  
  @FXML
  public void findProduct(ActionEvent event){
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            String searchProduct = this.id.getText();
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID= '" + searchProduct + "'");
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6) , rs.getString(7), rs.getString(8), rs.getString(9)));
            }
            
            rs.close();
            conn.close();
      
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
  
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.sizecolumn.setCellValueFactory(new PropertyValueFactory("size"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.locationcolumn.setCellValueFactory(new PropertyValueFactory("location"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.subcatcolumn.setCellValueFactory(new PropertyValueFactory("subcategory"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
            
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
  }
  
  // findProduct2 is used only inside initialize method
  public void findProduct2(){
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            //store the selling product id in an arraylist (sellingProducts)
            this.sellingProducts.add(this.id.getText());
                       
            String myquery = new StringBuilder().append("SELECT * FROM products WHERE ").toString();
            
            for(String s : sellingProducts) {                
                myquery = new StringBuilder().append(myquery).append("productID = '").append(s).append("' OR ").toString();
                
            }
            
            // Append this final element that is always false, so it doesnot affect the query result. Just to close correctly the query as the loop above adds a final OR.
            myquery = new StringBuilder().append(myquery).append("productID = 'whiskeyInTheJaro'").toString();
            
            ResultSet rs = conn.createStatement().executeQuery(myquery);
            
            while (rs.next())
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6) , rs.getString(7), rs.getString(8), rs.getString(9)));
            
            rs.close();
            conn.close();
      
      } catch(SQLException e){
          System.err.println("Error " + e);
      }
      
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.sizecolumn.setCellValueFactory(new PropertyValueFactory("size"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.locationcolumn.setCellValueFactory(new PropertyValueFactory("location"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.subcatcolumn.setCellValueFactory(new PropertyValueFactory("subcategory"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
      
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
  }

    
  @FXML
  public void clearFields(ActionEvent event) { 
    
      
    this.id.setText(""); 
    this.quantity.setValue(null);
    this.category.setValue(null);
    
    sublist = FXCollections.observableArrayList("Select category");
    this.subcategory.setItems(sublist);
    this.subcategory.setValue(null);    
    
    this.supplier.setValue(null);
    
    // set prompt text in the combo boxes
    this.quantity.setPromptText("select");
    this.category.setPromptText("Category");
    this.subcategory.setPromptText("Sub-category");
    this.supplier.setPromptText("Supplier");

    
  }
  
  // used only inside initialize method
  private void clearFields2() { 
    
        
    this.id.setText(""); 
    this.quantity.setValue(null);
    this.category.setValue(null);
    
    sublist = FXCollections.observableArrayList("Select category");
    this.subcategory.setItems(sublist);
    this.subcategory.setValue(null);    
    
    this.supplier.setValue(null);
    
     // set prompt text in the combo boxes
    this.quantity.setPromptText("select");
    this.category.setPromptText("Category");
    this.subcategory.setPromptText("Sub-category");
    this.supplier.setPromptText("Supplier");
      
  }
  
  
  @FXML
  public void minusOneProduct(ActionEvent event){
    int qtylimit=0;
    
    // find the quantity of the product that we want to sell and so remove one iten from quantity
    try{
        Connection conn = dbConnection.getConnection();
        ResultSet rs = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID= '" + this.id.getText() + "'");
        qtylimit = rs.getInt(1); 
        
        rs.close();
        conn.close();
    
    } catch(SQLException e){
        System.err.println("Got an exception-1!");
        System.err.println(e.getMessage());
    
    }
    
    // if quantity is over zero then reduce the qty by one item
    if(qtylimit>0)  {
        
        String sql = "UPDATE `products` SET quantity=quantity-1 WHERE productID=?";
        try {
            Connection conn = dbConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());
            stmt.execute();
            stmt.close();
            
            findProduct(event); // call this method to refresh the table's data
            
            // write action to log file
            ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity, category FROM products WHERE productID='" + this.id.getText()+ "'");
            String productname = rs.getString(1);
            String Psize = rs.getString(2);
            int Pqty = rs.getInt(3);
            rs.close();
            
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            
            ReadWriteLog logObject = new ReadWriteLog();
            logObject.logWriteFunction("Log Action: Minus ONE Item. "+"Product ID= " + this.id.getText() + ".\nName= "+ productname + ". Size= " + Psize + ". New QTY= " + Pqty+ 
                    ".\nTime= " + timeStamp + "\n");
            // end writing action to log file
            
            // save the sale of the product to the sales table by creating new record or by increasing the sold items number accordingly 
            
            String date1 = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            
            // search the table sales if there already exists a record with the specific product ID and for the current date
            ResultSet rs3 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE productID= '" + this.id.getText()+ "' AND date= '" + date1 + "'");
            
            int itemsNumber=0;
             
            // checking if ResultSet is empty, because the first time we sell a product there is not a value for items in rs3
            if (rs3.next() == false)
                System.out.println("ResultSet is empty!");
            else 
                itemsNumber = rs3.getInt(1);
            
            rs3.close();
            
            if(itemsNumber>0) { // Means there is already a record with the specific product ID and for the current date
                
                String sqlUpdateItems = "UPDATE `sales` SET items=items+1 WHERE productID=? AND date=?";
                
                PreparedStatement stmtUpdateItems = conn.prepareStatement(sqlUpdateItems);
                stmtUpdateItems.setString(1, this.id.getText());
                stmtUpdateItems.setString(2, date1.toString());
                stmtUpdateItems.execute();
                stmtUpdateItems.close();
                
            } else { // Means there is not a record and we have to create a new record
            
                String in = "INSERT INTO `sales`(`productID`, `items`, `date`) VALUES (?, ?, ?)";
            
                PreparedStatement stmt2 = conn.prepareStatement(in);
                stmt2.setString(1, this.id.getText());
                stmt2.setInt(2, 1);
                stmt2.setString(3, date1.toString());
                stmt2.execute();
            
                stmt2.close();
            }
            
            conn.close();
      
        } catch (SQLException e) {
            System.err.println("Got an exception-2!");
            System.err.println(e.getMessage());
        }
        
    }
    
  }

  // used only inside initialize method
  public void minusOneProduct2(){
    int qtylimit=0;
    
    // find the quantity of the product that we want to sell and so remove one iten from quantity
    try{
        Connection conn = dbConnection.getConnection();
        ResultSet rs = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID= '" + this.id.getText() + "'");
        
        // checking if ResultSet is empty, because there was an SQLException when running the app for the first time without any products in the database 
        if (rs.next() == false)
            System.out.println("ResultSet is empty!");
        else 
            qtylimit = rs.getInt(1); 
        
        rs.close();
        conn.close();
    
    } catch(SQLException e){
        System.err.println("Got an exception-3!");
        System.err.println(e.getMessage());
    
    }
    
    // if quantity is over zero then reduce the qty by one item
    if(qtylimit>0){
        
        String sql = "UPDATE `products` SET quantity=quantity-1 WHERE productID=?";
        try {
            Connection conn = dbConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());
            stmt.execute();
            stmt.close();
            
            // write data to the log file
            ResultSet rs4 = conn.createStatement().executeQuery("SELECT productName, size, quantity FROM products WHERE productID='" + this.id.getText()+ "'");
            
            // checking if ResultSet is empty 
            if (rs4.next() == false)
                System.out.println("ResultSet is empty!");
            else{
                String productname = rs4.getString(1);
                String Psize = rs4.getString(2);
                int Pqty = rs4.getInt(3);
                String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

                ReadWriteLog logObject = new ReadWriteLog();

                logObject.logWriteFunction("Log Action: Minus ONE Item. "+"Product ID= " + this.id.getText() + ".\nName= "+ productname + ". Size= " + Psize + ". New QTY= " + Pqty+ 
                        ".\nTime= " + timeStamp + "\n");
                
                // end of writing to log file
                
            }
            rs4.close();
            
             // save the sale of the product to the sales table by creating new record or by increasing the sold items number accordingly 
            
            String date1 = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            
            // search the table sales if there already exists a record with the specific product ID and for the current date
            ResultSet rs3 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE productID= '" + this.id.getText()+ "' AND date= '" + date1 + "'");
                        
            int itemsNumber=0;
             
            // checking if ResultSet is empty, because the first time we sell a product there is not a value for items in rs3
            if (rs3.next() == false)
                System.out.println("ResultSet is empty!");
            else 
                itemsNumber = rs3.getInt(1);
            
            
            rs3.close();
            
            if(itemsNumber>0) { // Means there is already a record with the specific product ID and for the current date
                
                String sqlUpdateItems = "UPDATE `sales` SET items=items+1 WHERE productID=? AND date=?";
                
                PreparedStatement stmtUpdateItems = conn.prepareStatement(sqlUpdateItems);
                stmtUpdateItems.setString(1, this.id.getText());
                stmtUpdateItems.setString(2, date1.toString());
                stmtUpdateItems.execute();
                stmtUpdateItems.close();
                
            } else { // Means there is not a record and we have to create a new record
            
                String in = "INSERT INTO `sales`(`productID`, `items`, `date`) VALUES (?, ?, ?)";
            
                PreparedStatement stmt2 = conn.prepareStatement(in);
                stmt2.setString(1, this.id.getText());
                stmt2.setInt(2, 1);
                stmt2.setString(3, date1.toString());
                stmt2.execute();
                stmt2.close();
            }
            
            conn.close();
            
      
        } catch (SQLException e) {
            System.err.println("Got an exception-4!");
            System.err.println(e.getMessage());
        }
        
    }
    
  }
  
  
  @FXML
  public void loadSubcategoryItems (ActionEvent event){
          
    boolean isCategoryEmpty = category.getSelectionModel().isEmpty();
    
    //user selected item on category combobox
    if (!isCategoryEmpty){
        String tempcat = this.category.getValue(); 
        
        // loading the subcategories per category (tempcat)
        loadCategories ob2 = new loadCategories();
        sublist = ob2.getSubCategories(tempcat);        
        
        // connect combobox and list of items for sub-category combobox
        subcategory.setItems(sublist);
        
    }   
            
  }
 
 
  
  @FXML
  private void logread(ActionEvent event){
      
      ReadWriteLog o = new ReadWriteLog();
      o.logReadFunction(event);
      
  }

  
  @FXML
  public void printDataForms(ActionEvent event) {
    try {
      Stage dataStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane datapane = (Pane)loader.load(getClass().getResource("/students/printDataFXML.fxml").openStream());
      
      Scene datascene = new Scene(datapane);
      datascene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());
      
      // change the default app icon appearing on the system tray. working only for windows OS.
      Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
      dataStage.getIcons().add(icon);
      
      dataStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
      dataStage.setScene(datascene);
      dataStage.setTitle("Print Data Forms");
      dataStage.setResizable(false);
      dataStage.showAndWait(); //Display window and wait for it to be closed before returning
    } catch (IOException e) {
      e.printStackTrace();
      
    }
    
  }
  
  
    @FXML
    public void browseFormsFolder(ActionEvent event) throws IOException, Exception {
        
        if(Utils.isWindows()){
            
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Doc File");
            fileChooser.setInitialDirectory(new File("forms"));
            fileChooser.getExtensionFilters().addAll(
            new ExtensionFilter("Doc Files", "*.odt", "*.doc", "*.docx", "*.docm"),
            new ExtensionFilter("Text Files", "*.txt"),
            new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                String path = selectedFile.getAbsolutePath();
                
                Desktop.getDesktop().open(new File(path));
                
                //Runtime.getRuntime().exec(new String[]{"start winword ", path});
                
                Runtime.getRuntime().exec(new String[]{"winword ", path});
                
                //Runtime.getRuntime().exec(new String[]{"start ", path});
            }
        
        } else { //Linux
        
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Doc File");
            //fileChooser.setInitialDirectory(new File("forms"));
            fileChooser.getExtensionFilters().addAll(
            new ExtensionFilter("Doc Files", "*.odt", "*.doc", "*.docx", "*.docm"),
            new ExtensionFilter("Text Files", "*.txt"),
            new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                String path = selectedFile.getAbsolutePath();
                Runtime.getRuntime().exec(new String[]{"libreoffice",path});
            }
            
        }
        
    }
    
    @FXML
    public void browseLogFolder(ActionEvent event) throws IOException {
        
        if(Utils.isWindows()){
            
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Log File");
            fileChooser.setInitialDirectory(new File("log"));
            fileChooser.getExtensionFilters().addAll(
            new ExtensionFilter("Text Files", "*.txt"),
            new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            String filePath = selectedFile.getAbsolutePath();
            
            Runtime rt = Runtime.getRuntime();

            if(filePath!= null){
                try {
                    Process p = rt.exec("notepad " + filePath);
                } catch (IOException ex) {
                    Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        } else { //Linux machine
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Log File");
            //fileChooser.setInitialDirectory(new File("log"));
            fileChooser.getExtensionFilters().addAll(
            new ExtensionFilter("Text Files", "*.txt"),
            new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                ProcessBuilder pb = new ProcessBuilder("gedit", new StringBuilder().append(selectedFile.toString()).toString());
                pb.start();
            }
        
        }
        
        
    }

  @FXML
  public void openInventory(ActionEvent event){
      
        // check the free version limitations
        boolean withinLimits=false, withinLimits2=false;
        
        freeVersionLimitations limitationsObject = new freeVersionLimitations();
        
        limitationsObject.checkTheSystemsClock();
        withinLimits = limitationsObject.checkProductsNumber();
        withinLimits2 = limitationsObject.checkSalesNumber();
        
        //create object of class AlertBox 
        AlertBox alertOb = new AlertBox();
        
        if (!withinLimits || !withinLimits2) {
        
            alertOb.showfreeVersionLimitsError();
            
            try {
                Thread.sleep(5000);
            }
            catch (InterruptedException e2) {
                // log the exception
                System.err.println("System Mac Exp : " + e2.getMessage());
            }
            
            System.exit(0);
        
        
        }  
      
        try
        {
          Stage inventoryStage = new Stage();
          FXMLLoader loader = new FXMLLoader();
          Pane inventoryroot = (Pane)loader.load(getClass().getResource("/inventorymanagement/InventoryFXML.fxml").openStream());
          InventoryFXMLcontroller inventoryController = (InventoryFXMLcontroller)loader.getController();

          Scene inventoryscene = new Scene(inventoryroot);
          inventoryscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());

          // change the default app icon appearing on the system tray. working only for windows OS.
          Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
          inventoryStage.getIcons().add(icon);

          inventoryStage.initModality(Modality.NONE); 
          //inventoryStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
          inventoryStage.setScene(inventoryscene);
          inventoryStage.setTitle("OPTIFLOW v1.0");
          inventoryStage.setResizable(true);
          inventoryStage.showAndWait();
        }
        catch (IOException e)
        {
          e.printStackTrace();

        }
  
  }
  
  public void checkProductsLimits() {
        // set the flag to false so that it does not check the limits again. Only one time per application use
        flagAlertBox=false;
        
        // load the limits per category from the settings txt file
        ArrayList<Integer> productLimits = new ArrayList<>();
        SettingsController ob = new SettingsController();
        productLimits = ob.settingsReadFunction3();
        
        // write action to log file
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        ReadWriteLog logObject = new ReadWriteLog();
        logObject.logWriteFunction("Log Action: Check Products QTY per Category. Time:" + timeStamp );
        
        // initialize some variables
        int qtylimit=1000000;
        boolean flagBelowLimit = false;
        
        ObservableList<String> categList = FXCollections.observableArrayList();
    
        // find the minimum existing qty of the products in each category
        try{
            // load the categories in a list
            loadCategories loadOb = new loadCategories();
            categList = loadOb.getCategories();
                        
            Connection conn = dbConnection.getConnection();
            int i=0;
            for(String temp:categList) {
                
                ResultSet rs = conn.createStatement().executeQuery("SELECT MIN(quantity) FROM products WHERE category= '"+ temp + "'");
                qtylimit = rs.getInt(1);
                rs.close();
                if(qtylimit<productLimits.get(i)) {
                    flagBelowLimit=true;
                    logObject.logWriteFunction(temp + ": Products with Qty Below Limit of "+ productLimits.get(i) + " items");
                }
                else {
                    logObject.logWriteFunction(temp +": Qty OK");
                }
            
                i++;
            }
            logObject.logWriteFunction("\n");
            
            
            conn.close();
            
            if (flagBelowLimit) {
                AlertBox ob1 = new AlertBox();
                ob1.showQtyWarningAlert();
            
            }
            else {
                logObject.logWriteFunction("All Categories have sufficient Qty of items\n");
            }
            
        } catch(SQLException e){
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());

        }
      
        
  }  
  
  
}