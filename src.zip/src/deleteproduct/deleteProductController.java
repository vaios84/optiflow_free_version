
package deleteproduct;

import alertBox.AlertBox;
import dbUtil.dbConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import readWriteLog.ReadWriteLog;

public class deleteProductController implements Initializable {
    
    
  @FXML
  private TextField id;
  @FXML
  private TextField pname;
  @FXML
  private TextField size;  
  @FXML
  private TextField qty;
  @FXML
  private TextField supplierCompany;
  
  
  @FXML
  private Button findbutton;  
  @FXML
  private Button deletebutton;  
  
  @FXML
  private Button cancelbutton;  
  
  private dbConnection dc;
  
  
  @Override
  public void initialize(URL url, ResourceBundle rb) {
      this.dc = new dbConnection();
      
      // make a textfield automatically clicked with cursor and ready for user input
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
            id.requestFocus();
            }
        });
        
        // product id typing or scanning and listen for ENTER key, then find the product
        // barcode scanners provide automatically a barcode ID and ENTER key
        id.setOnKeyPressed(new EventHandler<KeyEvent>()
        {
            @Override
            public void handle(KeyEvent ke)
            {   
                        
                if (ke.getCode().equals(KeyCode.ENTER))
                {
                findProduct2();
               
                }
            }
        });
        
  }
  
  @FXML
  private void findProduct(ActionEvent event){
      try
      {
            Connection conn = dbConnection.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity, supplier FROM products WHERE productID= '" + this.id.getText() + "'");
            
            // checking if ResultSet is empty
            if (rs.next() == false)
                    System.out.println("ResultSet is empty!");
            else {
            
                    this.pname.setText(rs.getString(1));
                    this.size.setText(rs.getString(2));       
                    this.qty.setText(rs.getString(3));
                    this.supplierCompany.setText(rs.getString(4));
            
            }
            
            conn.close();
      } 
      catch(SQLException e)
      {
          System.err.println("Error " + e);   
      }
  
      
  }
  
  private void findProduct2(){
      try
      {
            Connection conn = dbConnection.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT productName, size, quantity, supplier FROM products WHERE productID= '" + this.id.getText() + "'");
            
            // checking if ResultSet is empty
            if (rs.next() == false)
                System.out.println("ResultSet is empty!");
            else {
            
                this.pname.setText(rs.getString(1));
                this.size.setText(rs.getString(2));       
                this.qty.setText(rs.getString(3));
                this.supplierCompany.setText(rs.getString(4));
            
            }
            
            conn.close();
      } 
      catch(SQLException e)
      {
          System.err.println("Error " + e);   
      }
  
      
  }
  
  @FXML
  private void removeProduct(ActionEvent event) {
      
      AlertBox alert1 = new AlertBox();
      int reply = alert1.displayDeleteConfirmation();
      
      if (reply==0) return;
      
      String sql = "DELETE FROM `products` WHERE productID=? "; 
      try{
          Connection conn = dbConnection.getConnection();
          
          // need the product name for the write action to log file 
          ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID='" + this.id.getText() +"'");
          
          // checking if ResultSet is empty
          if (rs.next() == false)
                System.out.println("ResultSet is empty!");
          else {
          
                String productname = rs.getString(2);
                String productsize = rs.getString(3);
                String productQty = rs.getString(4);
                String productLoc = rs.getString(5);
                String productCat = rs.getString(6);
                String productSubcat = rs.getString(7);
                String productprice = rs.getString(8);
                String productSup = rs.getString(9);
                
                
                // then delete the product
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, this.id.getText());

                if(this.id.getText()!=null && this.id.getText().trim().length()>0) {
                      stmt.execute();

                      // write action to log file          
                      String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
                      ReadWriteLog logObject = new ReadWriteLog();

                      logObject.logWriteFunction("--------------------------------------------------------");
                      logObject.logWriteFunction("Log Action: Delete Product. "+"\nProduct ID= " + this.id.getText() + ". Name= " + productname +
                              ".\nSize= " + productsize + ". QTY= "+ productQty + ". Location= " + productLoc +  
                              ".\nCategory= " + productCat + ". Sub-cat= " + productSubcat + 
                              ".\nPrice=" + productprice + ". Supplier=" + productSup + 
                              ".\nTime= " + timeStamp);

                      logObject.logWriteFunction("--------------------------------------------------------");                

                      // show the alert box
                      AlertBox ob1 = new AlertBox();
                      ob1.showInfoAlert2();

                      clearFields(event);
                }
          
          
                
          }
          
          conn.close();
      
      } catch (SQLException e) {
          System.err.println("Got an exception!");
          System.err.println(e.getMessage());
      
      }
      
  }
    
  
  @FXML
  public void goback(ActionEvent event) {
        Stage stage = (Stage)this.cancelbutton.getScene().getWindow();
        stage.close();    
        
    }

  @FXML
  private void clearFields(ActionEvent event) { 
    
    this.id.setText("");   
    this.pname.setText("");   
    this.size.setText("");   
    this.qty.setText("");   
    this.supplierCompany.setText("");   
    
  }
  
  
}
