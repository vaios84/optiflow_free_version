
package deleteproduct;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class deleteProductModel {  
    
    private final StringProperty pid;
    private final StringProperty pname;
    private final StringProperty size;
    private final StringProperty quantity;
    private final StringProperty location;
    private final StringProperty category;
    private final StringProperty subcategory;
    private final StringProperty price;
    private final StringProperty supplier;
    
    // Constructor
    public deleteProductModel (String pid, String pname, String size, String quantity, String location, String category, String subcategory, String price, String supplier) {
          this.pid = new SimpleStringProperty(pid);
          this.pname = new SimpleStringProperty(pname);
          this.size = new SimpleStringProperty(size);
          this.quantity = new SimpleStringProperty(quantity);
          this.location = new SimpleStringProperty(location);
          this.category = new SimpleStringProperty(category);
          this.subcategory = new SimpleStringProperty(subcategory);
          this.price = new SimpleStringProperty(price);
          this.supplier = new SimpleStringProperty(supplier);
      }
      
    // Getter methods
    public String getPid() {
        return (String)this.pid.get();
    }

    public String getPname() {
        return (String)this.pname.get();
    }
    
    public String getSize() {
        return (String)this.size.get();
    }

    public String getQuantity() {
        return (String)this.quantity.get();
    }
    
    public String getLocation() {
        return (String)this.location.get();
    }

    public String getCategory() {
        return (String)this.category.get();
    }
    
    
    public String getSubcategory() {
        return (String)this.subcategory.get();
    }

    public String getPrice() {
        return (String)this.price.get();
    }
    
    public String getSupplier() {
        return (String)this.supplier.get();
    }
      
    // Setter methods    
    public void setPid(String value) {
        this.pid.set(value);
    }
    
    public void setPname(String value) {
        this.pname.set(value);
    }      
    
    public void setSize(String value) {
        this.size.set(value);
    }
    
    public void setQuantity(String value) {
        this.quantity.set(value);
    }
    
    public void setLocation(String value) {
        this.location.set(value);
    }
    
    public void setCategory(String value) {
        this.category.set(value);
    }
    
    public void setSubcategory(String value) {
        this.subcategory.set(value);
    }
    
    public void setPrice(String value) {
        this.price.set(value);
    }
    
    public void setSupplier(String value) {
        this.supplier.set(value);
    }
    
    // Getter methods for String Properties
    public StringProperty pidProperty() {
        return this.pid;
    }
    
    public StringProperty pnameProperty() {
        return this.pname;
    }
    
    public StringProperty sizeProperty() {
        return this.size;
    }
    
    public StringProperty quantityProperty() {
        return this.quantity;
    }
    
    public StringProperty locationProperty() {
        return this.location;
    }
    
    public StringProperty categoryProperty() {
        return this.category;
    }
    
    public StringProperty subcategoryProperty() {
        return this.subcategory;
    }
    
    public StringProperty priceProperty() {
        return this.price;
    }
    
    public StringProperty supplierProperty() {
        return this.supplier;
        
    }

    
    
    
}
