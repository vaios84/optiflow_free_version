
package addnewproduct;

import alertBox.AlertBox;
import dbUtil.dbConnection;
import dbUtil.loadCategories;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import readWriteLog.ReadWriteLog;
import students.ProductData;

public class addNewProductController implements Initializable {
    
  @FXML
  private TextField id;
  @FXML
  private TextField pname;
  @FXML
  private TextField size;  
  @FXML
  private TextField qty;
  @FXML
  private TextField location;
  
  // create combobox category and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> category;
  private ObservableList<String> list = FXCollections.observableArrayList();
  
  // create combobox sub-category and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> subcategory;
  private ObservableList<String> sublist = FXCollections.observableArrayList("Select category");
  
  @FXML
  private TextField price;
  
  // create combobox and a list to connect it later inside initialize function
  @FXML
  private ComboBox<String> supplier;
  private ObservableList<String> supplierlist;
  
  
  @FXML
  private Button addproductbutton;
  @FXML
  private Button cancelbutton;
    
  
  
  private ObservableList<ProductData> data;  
  private dbConnection dc;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
      this.dc = new dbConnection();
      
      // populating the list with the categories from the sql database
      loadCategories ob1 = new loadCategories();
      list = ob1.getCategories();
      
      // connect combobox and list of items for category combobox
      category.setItems(list);
      
      // connect combobox and list of items for sub-category combobox
      subcategory.setItems(sublist);
      
      
      // connect combobox and list of items for Suppliers Combobox
      try{
            Connection conn = dbConnection.getConnection();
            this.supplierlist = FXCollections.observableArrayList();
            
            ResultSet rs2 = conn.createStatement().executeQuery("SELECT company FROM suppliers");
            while (rs2.next()) {
                this.supplierlist.add(rs2.getString(1));
            }      
            supplier.setItems(supplierlist);
            
            conn.close();
            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
      
      // create a 4digit, random product ID in the range 1000 - 9999
      Random rand = new Random();
      int pickedNumber = rand.nextInt(8999) + 1000;
      String timeStamp = new SimpleDateFormat("yyMMdd").format(new Date());
      this.id.setText(timeStamp+pickedNumber);
        
    }
    
    
    
    @FXML
    public void loadSubcategoryItems (ActionEvent event){

        boolean isCategoryEmpty = category.getSelectionModel().isEmpty();

        //user selected item on category combobox
        if (!isCategoryEmpty){
            String tempcat = this.category.getValue(); 

            // loading the subcategories per category (tempcat)
            loadCategories ob2 = new loadCategories();
            sublist = ob2.getSubCategories(tempcat);        

            // connect combobox and list of items for sub-category combobox
            subcategory.setItems(sublist);

        }   
        
    }

    
    @FXML
    private void addProduct(ActionEvent event){
    
    String sql = "INSERT INTO `products`(`productID`, `productName`, `size`, `quantity`, `location`, `category`, `subcategory`, `price`, `supplier`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try {
      Connection conn = dbConnection.getConnection();
      
      AlertBox ob1 = new AlertBox();
      
     
      // check that no items with blank id or name are inserted in my db
      if( this.id.getText()!=null && this.id.getText().trim().length()>0 && 
          this.pname.getText()!=null && this.pname.getText().trim().length()>0 && 
          this.qty.getText()!=null && this.qty.getText().trim().length()>0 && 
          this.category.getValue()!= null && this.subcategory.getValue()!= null && this.supplier.getValue()!= null ) {
          
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());
            stmt.setString(2, this.pname.getText());
            stmt.setString(3, this.size.getText());
            stmt.setString(4, this.qty.getText());
            stmt.setString(5, this.location.getText());
            stmt.setString(6, this.category.getValue());
            stmt.setString(7, this.subcategory.getValue());
            stmt.setString(8, this.price.getText());
            stmt.setString(9, this.supplier.getValue());  

            stmt.execute();      

            // write action to log file
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            ReadWriteLog logObject = new ReadWriteLog();
            
            logObject.logWriteFunction("Log Action: Add New Product. "+"Product ID= " + this.id.getText() + ". Name = " + this.pname.getText() + ".\nTime= " + timeStamp +"\n");

            //show the alert
            ob1.showInfoAlert(); 

            //clear textfields 
            clearFields(event);

            // create a 4digit, random product ID in the range 1000 - 9999
            Random rand = new Random();
            int pickedNumber = rand.nextInt(8999) + 1000;
            timeStamp = new SimpleDateFormat("yyMMdd").format(new Date());
            this.id.setText(timeStamp+pickedNumber);

      }
      else { ob1.showProductInfoAlert(); } 
      
      conn.close();
      
    } catch (SQLException e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
    
  }
    
    
    @FXML
    public void goback(ActionEvent event) {
        Stage stage = (Stage)this.cancelbutton.getScene().getWindow();
        stage.close();    
        
    }
    
    @FXML
    private void clearFields(ActionEvent event) { 
    
        this.id.setText("");
        this.pname.setText("");
        this.size.setText("");
        this.qty.setText("");
        this.location.setText("");
        this.category.setValue(null);

        sublist = FXCollections.observableArrayList("Select category");
        this.subcategory.setItems(sublist);
        this.subcategory.setValue(null);
        
        this.price.setText("");
        this.supplier.setValue(null);

    }
    
    
}
