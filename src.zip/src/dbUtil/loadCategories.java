/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbUtil;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;

/**
 *
 * @author vaios stergiopoulos
 */
public class loadCategories implements Initializable {
    
    private dbConnection dc;
    // create lists for the categories and subcategories
    private ObservableList<String> categList = FXCollections.observableArrayList();
    private ObservableList<String> subcategList = FXCollections.observableArrayList();
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.dc = new dbConnection();
        
    }
    
    
    public ObservableList<String> getCategories() {
                
        try {
            Connection conn = dbConnection.getConnection();
            ResultSet rs1 = conn.createStatement().executeQuery("SELECT category FROM categories");
            
            while(rs1.next())
                this.categList.add(rs1.getString(1));
                
            rs1.close();
            conn.close();
        }
        catch(SQLException e) {
            System.err.println("Error " + e);   
        }
        
        
        return categList;
     }
    
    
    public ObservableList<String> getSubCategories(String c) {
        
        String str = null;
                
        try {
            Connection conn = dbConnection.getConnection();
            ResultSet rs2 = conn.createStatement().executeQuery("SELECT subcategory FROM categories WHERE category ='"+ c+ "'" );
            
            str = rs2.getString(1);
            
            // break the string of subcategories (Leather Shoes,Hunter Boots,Hiking Boots,Casual,Hiking Shoes,Runners,Sandals,Other)
            // on the comma separator and save it in a temporary list
            List<String> templist = new ArrayList<String>(Arrays.asList(str.split(",")));
            
            for (String temp : templist) this.subcategList.add(temp);
                
            rs2.close();
            conn.close();
        }
        catch(SQLException e) {
            System.err.println("Error " + e);   
        }
        
        
        return subcategList;
    }
    
    
    
    
}
