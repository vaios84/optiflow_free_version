/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbUtil;

import alertBox.AlertBox;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author vaios stergiopoulos
 */
public class freeVersionLimitations {
    
    public void checkTheSystemsClock(){
                
        // The date of the system today
        String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        //System.out.println("Date Today: " + today);
        
        // break the today date of the system into integer pieces
        //int d3 = parseInt(today.substring(8));
        //int m3 = parseInt(today.substring(5, 7));
        int y3 = parseInt(today.substring(0, 4));
        
        AlertBox alertOb = new AlertBox();
        
        // Check that the current year is NOT 2023 or more. optiflow v1.1 will function until the end of 2022
        if (y3>2022) {
            
            alertOb.showSystemClockError();
            
            try {
                Thread.sleep(5000);
            }
            catch (InterruptedException e2) {
                // log the exception
                System.err.println("System Mac Exp : " + e2.getMessage());
            }
            
            System.exit(0);
            
        }
        
        
    }
    
    
    public boolean checkProductsNumber(){
        int number=100; // product's number
        boolean withinLimits = false;
        
        //check that always the product's number is equal or below 30 (productLimit)
        try{
              Connection conn = dbConnection.getConnection();

              String myquery = new StringBuilder().append("SELECT COUNT(*) FROM products;").toString();
              ResultSet rs = conn.createStatement().executeQuery(myquery);
              
              number = rs.getInt(1); // real products number
              
              rs.close();
              conn.close();

        } catch(SQLException e){
            System.err.println("Error " + e);
        }
        
        //System.out.println("number= " + number);
        
        if(number <= 30) withinLimits = true;
      
      
      return withinLimits;
    }

    
    public boolean checkSalesNumber(){
            
        int salesnumber=5555; // sales number
        boolean withinLimits2 = false;
        
        //check that sales number is equal or below 5000 
        try{
              Connection conn = dbConnection.getConnection();

              String myquery = new StringBuilder().append("SELECT COUNT(*) FROM sales;").toString();
              ResultSet rs = conn.createStatement().executeQuery(myquery);
              
              salesnumber = rs.getInt(1); // real sales number
              
              rs.close();
              conn.close();

        } catch(SQLException e){
            System.err.println("Error " + e);
        }
        
        //System.out.println("salesnumber= " + salesnumber);
        
        if(salesnumber <= 5000) withinLimits2 = true;
      
      
      return withinLimits2;
    }

    
}
