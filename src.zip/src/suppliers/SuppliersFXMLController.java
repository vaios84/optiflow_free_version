
package suppliers;


import alertBox.AlertBox;
import com.sun.javafx.util.Utils;
import dbUtil.dbConnection;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SuppliersFXMLController implements Initializable {
    
  @FXML
  private TextField id;
  @FXML
  private TextField name;
  @FXML
  private TextField lname;
  @FXML
  private TextField company;
  @FXML
  private TextField email;   
  @FXML
  private TextField phone;
  @FXML
  private TextField city;
  @FXML
  private TextField address;
  @FXML
  private TextField rating;
  
  //table and table columns
  @FXML
  private TableView<SupplierModel> suppliertable;
  @FXML
  private TableColumn<SupplierModel, String> idcolumn;
  @FXML
  private TableColumn<SupplierModel, String> namecolumn;
  @FXML
  private TableColumn<SupplierModel, String> lnamecolumn;
  @FXML
  private TableColumn<SupplierModel, String> companycolumn;
  @FXML
  private TableColumn<SupplierModel, String> emailcolumn;  
  @FXML
  private TableColumn<SupplierModel, String> phonecolumn;
  @FXML
  private TableColumn<SupplierModel, String> citycolumn;
  @FXML
  private TableColumn<SupplierModel, String> addresscolumn;
  @FXML
  private TableColumn<SupplierModel, String> ratingcolumn;
  
  
  //buttons
  @FXML
  private Button addbutton;  
  @FXML
  private Button deletebutton;
  @FXML
  private Button updatebutton;  
  @FXML
  private Button clearbutton;
  @FXML
  private Button openprintbutton;
  @FXML
  private Button openFormsbutton;
  @FXML
  private Button refreshbutton;
  
  // the list items names must be the same as the actual columns in the db, in order the update method below to function properly 
  private ObservableList<String> updatelist = FXCollections.observableArrayList("email", "phone", "city", "address", "rating");
  
  private ObservableList<SupplierModel> data;
  private dbConnection dc;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        this.dc = new dbConnection();
        
        // make a textfield automatically clicked ana ready for user input
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                id.requestFocus();
            }
        });
        
         loadSuppliersData(); // call this method to initially load the table's data        
        
    }    
    
    
    @FXML
    public void loadSuppliersData() {
        try
        {
          Connection conn = dbConnection.getConnection();
          this.data = FXCollections.observableArrayList();

          ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM suppliers");
          while (rs.next()) {
            this.data.add(new SupplierModel(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9) ));
          }
          
          conn.close();
          
        }
        catch (SQLException e)
        {
          System.err.println("Error " + e);
        }

        this.idcolumn.setCellValueFactory(new PropertyValueFactory("id"));
        this.namecolumn.setCellValueFactory(new PropertyValueFactory("name"));
        this.lnamecolumn.setCellValueFactory(new PropertyValueFactory("lastname"));
        this.companycolumn.setCellValueFactory(new PropertyValueFactory("company"));
        this.emailcolumn.setCellValueFactory(new PropertyValueFactory("email"));
        this.phonecolumn.setCellValueFactory(new PropertyValueFactory("phone"));
        this.citycolumn.setCellValueFactory(new PropertyValueFactory("city"));
        this.addresscolumn.setCellValueFactory(new PropertyValueFactory("address"));
        this.ratingcolumn.setCellValueFactory(new PropertyValueFactory("rating"));

        this.suppliertable.setItems(null);
        this.suppliertable.setItems(this.data);
    }

  @FXML
  public void addSupplier(ActionEvent event)
  {
    String sql = "INSERT INTO `suppliers`(`id`, `name`, `lastname`, `company`, `email`, `phone`, `city`, `address`,`rating`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try
    {
      Connection conn = dbConnection.getConnection();
      
      AlertBox ob1 = new AlertBox();
      
      // check that no items with blank id, name, lastname and company name are inserted in my db
      if(this.id.getText().trim().length()>0 && this.id.getText()!=null && 
         this.name.getText().trim().length()>0 && this.name.getText()!=null &&  
         this.lname.getText().trim().length()>0 && this.lname.getText()!=null && 
         this.company.getText().trim().length()>0 && this.company.getText()!=null ) {
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());
            stmt.setString(2, this.name.getText());
            stmt.setString(3, this.lname.getText());
            stmt.setString(4, this.company.getText());
            stmt.setString(5, this.email.getText());
            stmt.setString(6, this.phone.getText());
            stmt.setString(7, this.city.getText());
            stmt.setString(8, this.address.getText());
            
            Double foo;
            
            try {
               foo = Double.parseDouble(this.rating.getText());
            }
            catch (NumberFormatException e)
            {
               foo = 0.0;
            }
            
            if(foo>10.0) // user gives a rating over 10
                stmt.setString(9, "10");
            else if (foo<0.0) //user gives a negative rating
                stmt.setString(9, "0");
            else
                stmt.setString(9, this.rating.getText());
            
            stmt.execute();
            loadSuppliersData(); // call this method to refresh the table's data
            
            //show the alert
            ob1.showGeneralAlert();
            
      }
      else {
            ob1.showSupplierInfoAlert();
      }
      
      conn.close();
    }
    catch (SQLException e)
    {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  }
  
  
  @FXML
  public void deleteSupplier(ActionEvent event)
  {
    // if the selected supplier is the Unknown default supplier, stop the delete procedure
    String supplierID = this.id.getText().trim(); 
    if(supplierID.equals("10001")) return;  
    
    AlertBox alert1 = new AlertBox();
    int reply = alert1.displayDeleteConfirmation();
    if (reply==0) return;
    
    
    String sql = "DELETE FROM `suppliers` WHERE id=?";
    try
    {
      Connection conn = dbConnection.getConnection();
      
      // check that no items with blank id are inserted in my db
      if(this.id.getText().trim().length()>0 && this.id.getText()!=null) {

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, this.id.getText());
        stmt.execute();

        loadSuppliersData(); // call this method to refresh the table's data

        //show the alert
        AlertBox ob1 = new AlertBox();
        ob1.showGeneralAlert();

      }
      conn.close();
    }
    catch (SQLException e)
    {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  }
  
  @FXML
  public void updateSupplier(ActionEvent event) 
  {
      try 
      {

        Stage dataStage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        Pane datapane = (Pane)loader.load(getClass().getResource("/suppliers/updateSuppliersFXML.fxml").openStream());

        Scene datascene = new Scene(datapane);
        datascene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());
        
        // change the default app icon appearing on the system tray. working only for windows OS.
        Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
        dataStage.getIcons().add(icon);

        dataStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
        dataStage.setScene(datascene);
        dataStage.setTitle("Update Suppliers Data");
        dataStage.setResizable(false);
        dataStage.showAndWait(); //Display window and wait for it to be closed before returning

      } 
      catch (IOException e) {e.printStackTrace();}
    
  }
  
  
   @FXML
  public void refreshTableData(ActionEvent event)
  {
      try
        {
          Connection conn = dbConnection.getConnection();
          this.data = FXCollections.observableArrayList();

          ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM suppliers");
          while (rs.next()) {
            this.data.add(new SupplierModel(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9) ));
          }
          
          conn.close();
          
        }
        catch (SQLException e)
        {
          System.err.println("Error " + e);
        }

        this.idcolumn.setCellValueFactory(new PropertyValueFactory("id"));
        this.namecolumn.setCellValueFactory(new PropertyValueFactory("name"));
        this.lnamecolumn.setCellValueFactory(new PropertyValueFactory("lastname"));
        this.companycolumn.setCellValueFactory(new PropertyValueFactory("company"));
        this.emailcolumn.setCellValueFactory(new PropertyValueFactory("email"));
        this.phonecolumn.setCellValueFactory(new PropertyValueFactory("phone"));
        this.citycolumn.setCellValueFactory(new PropertyValueFactory("city"));
        this.addresscolumn.setCellValueFactory(new PropertyValueFactory("address"));
        this.ratingcolumn.setCellValueFactory(new PropertyValueFactory("rating"));
        
        this.suppliertable.setItems(null);
        this.suppliertable.setItems(this.data);
      
  }

  
  @FXML
  public void clearFields(ActionEvent event) {
    this.id.setText("");
    this.name.setText("");
    this.lname.setText("");
    this.company.setText("");
    this.email.setText("");
    this.phone.setText("");
    this.city.setText("");
    this.address.setText("");
    this.rating.setText("");  
  }
  
    
  @FXML
  public void printSuppliers(ActionEvent event) {
    try {
      Stage dataStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane datapane = (Pane)loader.load(getClass().getResource("/suppliers/printSuppliersFXML.fxml").openStream());
      
      Scene datascene = new Scene(datapane);
      datascene.getStylesheets().add(getClass().getResource("/CSS/smallwindow.css").toExternalForm());
      
      // change the default app icon appearing on the system tray. working only for windows OS.
      Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
      dataStage.getIcons().add(icon);
      
      dataStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
      dataStage.setScene(datascene);
      dataStage.setTitle("Print Suppliers");
      dataStage.setResizable(false);
      dataStage.showAndWait(); //Display window and wait for it to be closed before returning
    } catch (IOException e) {
      e.printStackTrace();
      
    }
    
  }
  
  @FXML
  public void browseFormsFolder(ActionEvent event) throws IOException, Exception {
        
        if(Utils.isWindows()){
            
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Doc File");
            fileChooser.setInitialDirectory(new File("forms"));
            fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Doc Files", "*.odt", "*.doc", "*.docx", "*.docm"),
            new FileChooser.ExtensionFilter("Text Files", "*.txt"),
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new FileChooser.ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                String path = selectedFile.getAbsolutePath();
                
                Desktop.getDesktop().open(new File(path));
                
                //Runtime.getRuntime().exec(new String[]{"start winword ", path});
                
                //Runtime.getRuntime().exec(new String[]{"winword ", path});
                
                Runtime.getRuntime().exec(new String[]{"start ", path});
            }
        
        } else { //Linux
        
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Doc File");
            //fileChooser.setInitialDirectory(new File("forms"));
            fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Doc Files", "*.odt", "*.doc", "*.docx", "*.docm"),
            new FileChooser.ExtensionFilter("Text Files", "*.txt"),
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
            new FileChooser.ExtensionFilter("HTML Files", "*.htm"),
            //new ExtensionFilter("Audio Files", "*.wav", "*.mp3", "*.aac"),
            new FileChooser.ExtensionFilter("All Files", "*.*"));

            File selectedFile = fileChooser.showOpenDialog(new Stage());
            
            if(selectedFile!= null){
                String path = selectedFile.getAbsolutePath();
                Runtime.getRuntime().exec(new String[]{"libreoffice",path});
            }
            
        }
        
    }
    
  
    
}
