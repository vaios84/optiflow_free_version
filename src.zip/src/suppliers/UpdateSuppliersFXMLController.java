
package suppliers;

import alertBox.AlertBox;
import dbUtil.dbConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UpdateSuppliersFXMLController implements Initializable {

    //buttons
    @FXML
    private Button findbutton;
    @FXML
    private Button updatebutton;
    @FXML
    private Button gobackbutton;
    
    // data input fields
    @FXML
    private TextField id;
    @FXML
    private TextField name;
    @FXML
    private TextField lastname;
    @FXML
    private TextField company;
    @FXML
    private TextField email;
    @FXML
    private TextField phone;
    @FXML
    private TextField city;
    @FXML
    private TextField address;
    @FXML
    private TextField rating;
    
    
    private ObservableList<SupplierModel> data;
    
    private static boolean supplierFound;
    
    //connection object
    private dbConnection dc;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        this.dc = new dbConnection(); 
        supplierFound = false;
        loadSupplierData(); // initial loading of the users data
        
    }
    
    private void loadSupplierData() {
        try
        {
          Connection conn = dbConnection.getConnection();
          this.data = FXCollections.observableArrayList();

          ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM suppliers");
          while (rs.next())
                this.data.add(new SupplierModel(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));

          conn.close();
        }
        catch (SQLException e)
        {
          System.err.println("Error " + e);
        }

    }
    
    
    @FXML
    private void findSupplier(ActionEvent event) {
        try{
            Connection conn = dbConnection.getConnection();            
            
            String search = this.id.getText().trim();
            
            // if the selected supplier is the Unknown default supplier, stop the procedure of update
            if(search.equals("10001")) goback(event);
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM suppliers WHERE id= '" + search + "'");
            
            this.id.setText(rs.getString(1));
            this.name.setText(rs.getString(2));
            this.lastname.setText(rs.getString(3));       
            this.company.setText(rs.getString(4));
            this.email.setText(rs.getString(5));
            this.phone.setText(rs.getString(6));
            this.city.setText(rs.getString(7));
            this.address.setText(rs.getString(8));
            this.rating.setText(rs.getString(9));
            supplierFound = true;
                   
            conn.close();
      
        } catch(SQLException e){
          System.err.println("Error " + e);   
        }

    }
    
    
    
    @FXML
    private void updateSupplierData(ActionEvent event) 
    {   
        // protection for the case the user enters only id and hits update button (without first calling findUser). 
        // If this didnt exist all blank textfields whould be stored and delete all data.
        if(!supplierFound) return;
        
        // if the selected supplier is the Unknown default supplier, stop the procedure of update
        String search = this.id.getText();
        if(search.trim().equals("10001")) goback(event);
        
        String tempName = this.name.getText();
        String tempLname = this.lastname.getText();
        String tempCompany = this.company.getText();
        String tempEmail = this.email.getText();
        String tempPhone = this.phone.getText();
        String tempCity = this.city.getText();
        String tempAddress = this.address.getText();
        String tempR = this.rating.getText();
        
        Double foo;
        try {
               foo = Double.parseDouble(tempR);
        }
        catch (NumberFormatException e){
               foo = 0.0;
        }
            
        if(foo>10.0) // user gives a rating over 10
            tempR = "10";
        else if (foo<0.0) //user gives a negative rating
            tempR = "0";
        
        String sql = "UPDATE `suppliers` SET name ='" + tempName + "'," +
                                            "lastname = '" + tempLname + "'," +
                                            "company= '" + tempCompany + "'," +
                                            "email = '" + tempEmail + "'," +
                                            "phone = '" + tempPhone + "'," +
                                            "city = '" + tempCity + "'," +
                                            "address = '" + tempAddress + "'," +
                                            "rating = '" + tempR + "'" +
                                            " WHERE id=?";
        
        AlertBox ob1 = new AlertBox();
        
        try {
            
            if( this.id.getText().trim().length()>0 && this.id.getText()!=null && 
                this.name.getText().trim().length()>0 && this.name.getText()!=null &&  
                this.lastname.getText().trim().length()>0 && this.lastname.getText()!=null && 
                this.company.getText().trim().length()>0 && this.company.getText()!=null ) {

                Connection conn = dbConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, this.id.getText());
                stmt.execute();

                //show the alert
                ob1.showGeneralAlert();
                
                loadSupplierData(); // refresh data after the update action
                supplierFound = false;
                conn.close(); 

            }
            else {
                ob1.showSupplierInfoAlert();
            }
            
            
        } catch (SQLException e) {
          System.err.println("Got an exception!");
          System.err.println(e.getMessage());
        }

    }
  
    
    @FXML
    public void goback(ActionEvent event) {
        Stage stage = (Stage)this.gobackbutton.getScene().getWindow();
        stage.close();    
        
    }

      
    
}
