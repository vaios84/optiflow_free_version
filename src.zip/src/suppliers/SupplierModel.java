
package suppliers;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SupplierModel {
    
    private final StringProperty id;
    private final StringProperty name;
    private final StringProperty lastname;
    private final StringProperty company;
    private final StringProperty email;
    private final StringProperty phone;
    private final StringProperty city;
    private final StringProperty address;
    private final StringProperty rating;
    
    
    public SupplierModel(String id, String name, String lastname, String company, String email, String phone, String city, String address, String rating) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.lastname = new SimpleStringProperty(lastname);
        this.company = new SimpleStringProperty(company);
        this.email = new SimpleStringProperty(email);
        this.phone = new SimpleStringProperty(phone);
        this.city = new SimpleStringProperty(city);
        this.address = new SimpleStringProperty(address);
        this.rating = new SimpleStringProperty(rating);
        
    }

    public String getId() {
        return (String)this.id.get();
    }

    public String getName() {
        return (String)this.name.get();
    }

    public String getLastname() {
        return (String)this.lastname.get();
    }

    public String getCompany() {
        return (String)this.company.get();
    }
    
    public String getEmail() {
        return (String)this.email.get();
    }    
    
    public String getPhone() {
        return (String)this.phone.get();
    }

    public String getCity() {
        return (String)this.city.get();
    }

    public String getAddress() {
        return (String)this.address.get();
    }
    
    public String getRating() {
        return (String)this.rating.get();
    }
    
            
    public void setId(String value) {
        this.id.set(value);
    }        
            
    
    public void setName(String value) {
        this.name.set(value);
    }
    
    public void setLastname(String value) {
        this.lastname.set(value);
    }
    
    public void setCompany(String value) {
        this.company.set(value);
    }
    
    public void setEmail(String value) {
        this.email.set(value);
    }
    
    public void setPhone(String value) {
        this.phone.set(value);
    }
    
    public void setCity(String value) {
        this.city.set(value);
    }
    
    public void setAddress(String value) {
        this.address.set(value);
    }
    
    public void setRating(String value) {
        this.rating.set(value);
    }
    
          
}
