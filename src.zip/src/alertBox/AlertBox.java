
package alertBox;

import java.util.Optional;
import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;

public class AlertBox extends Application {
    
    // Static methods can be called without creating an object of this class AlertBox
    // You can write: AlertBox.display("Info Warning", "Qty less than 10")
    public static void display(String title, String message) {
        Stage window = new Stage();

        //Block events to other windows
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setHeight(100);
        window.setWidth(240);
        window.isResizable();
        
        Label label = new Label();
        label.setText(message);
        Button closeButton = new Button(" OK ");
        closeButton.setOnAction(e -> window.close());

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, closeButton);
        layout.setAlignment(Pos.CENTER);
        
        //Display window and wait for it to be closed before returning
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }
    
    
    // Show a Information Alert with header Text
    public void showGraphAlert1() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText("Categories Sales Graph");
        alert.setContentText("Create a graph with the total number of items sold per category, through the selected years period");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showGraphAlert2() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText("Total Sales Graph");
        alert.setContentText("Create a graph with the total number of items sold, through the selected years period");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showGraphAlert3() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText("Categories Sales Pie-chart");
        alert.setContentText("Create pie-chart with the number of items sold per category, through the selected years period. Also, sales percentages appear per category");
        alert.showAndWait();
    }

        
    // Show a Warning Alert
    public void showQtyWarningAlert() {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Products Warning Alert");
        alert.setHeaderText("Products Qty below limits!");
        // Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("Check the current log file for details!"); 
        alert.showAndWait();
    }
    
    // Show a Warning Alert
    public void showQtyWarningAlert2() {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Products Warning Alert");
        alert.setHeaderText("Qty below limits!");
        // Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("The product has Qty below the category's limit!");
        alert.showAndWait();
    }
    
    
    // Show a Information Alert with header Text
    public void showGeneralAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Database Information");
        alert.setHeaderText("Data update");
        alert.setContentText("Successful!");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showInfoAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Products Info Alert");
        alert.setHeaderText("Add product in database");
        alert.setContentText("New product added successfully!");
 
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showPrintFormAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Info Alert");
        alert.setHeaderText("Print Form");
        alert.setContentText("Successful!");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showUpdateAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Products Info Alert");
        alert.setHeaderText("Update product info");
        alert.setContentText("Successful!");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showLimitsUpdateAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Setting Limits Alert");
        alert.setHeaderText("Update Limits per Category");
        alert.setContentText("Successful!");
        alert.showAndWait();
    }
    
    
    // Show a Information Alert with header Text
    public void showInfoAlert2() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Products Info Alert");
        alert.setHeaderText("Delete product");
        alert.setContentText("Successful!");
        alert.showAndWait();
    }
    
    
    // Show a Information Alert with header Text
    public void showUpdateErrorAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Update Error Alert");
        alert.setHeaderText("Database not updated!");
        alert.setContentText("Please, provide a valid product ID");
 
        alert.showAndWait();
    }
    
    
    // Show a Information Alert with header Text
    public void showUserInfoAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("User Info Error Alert");
        alert.setHeaderText("Information missing");
        alert.setContentText("Please provide ID, name, lastname, user, password");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showProductInfoAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Product Info Error Alert");
        alert.setHeaderText("Information missing");
        alert.setContentText("Provide ID,name,qty,category,sub,supplier");
        alert.showAndWait();
    }
    
    // Show a Information Alert with header Text
    public void showSupplierInfoAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Supplier Info Error Alert");
        alert.setHeaderText("Information missing");
        alert.setContentText("Please provide ID, name, lastname, company");
        alert.showAndWait();
    }
    
    // Show Error
    public void showMacAddressFailError() {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("License Error");
        alert.setHeaderText("License-MAC Verification Fail");
        //Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("License Key Expired or Not registered MAC addr");
        alert.showAndWait();
    }
    
    // Show Error
    public void showLicenseKeyExpiredError() {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("License Key Error");
        alert.setHeaderText("License Verification Fail");
        //Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("Key Expired. Contact your local Optiflow support");
        alert.showAndWait();
    }
    
    
    // Show Error
    public void showSystemClockError() {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("System Clock Error");
        alert.setHeaderText("Date-time verification failed");
        //Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("Date-time error from system's clock");
        alert.showAndWait();
    }
    
    // Show a Warning Alert that you have a month left on your license
    public void showLicenseWarningOnTheLastMonth(String expDate) {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("License Key Warning");
        alert.setHeaderText("Expiration Date: " +expDate);
        // Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("Contact your local optiflow reseller");
        alert.showAndWait();
    }
    
    public int displayDeleteConfirmation() {
        int yes=0;
        
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setHeaderText("Caution");
        alert.setContentText("Are you sure you want to delete the item?");

        ButtonType deleteData = new ButtonType("Yes");
        ButtonType buttonTypeCancel = new ButtonType("No", ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(deleteData, buttonTypeCancel);
        Optional<ButtonType> result = alert.showAndWait();
        
        if (result.get() == deleteData) yes=1;
        //else yes=0; // the user chose CANCEL or closed the dialog 
        
        return yes;
    }
    
    public void showfreeVersionLimitsError(){
        
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Max limits exceeded");
        alert.setHeaderText("products or sales number limit");
        //Header Text null
        //alert.setHeaderText(null);
        alert.setContentText("Contact us for full version!");
        alert.showAndWait();
        
    }
    
    
    @Override
    public void start(Stage stage) throws Exception {
        VBox alertroot = new VBox();
        alertroot.setPadding(new Insets(10));
        alertroot.setSpacing(10);
 
        Scene alertscene = new Scene(alertroot, 450, 250);
        stage.setTitle("Warning Alert");
        stage.setScene(alertscene);
        stage.isResizable();
        
        showQtyWarningAlert();
        showQtyWarningAlert2();
        showInfoAlert();
        showInfoAlert2();
        showUpdateErrorAlert();
        showUpdateAlert();        
        showGeneralAlert();
        
        stage.show();
        
    }

}
