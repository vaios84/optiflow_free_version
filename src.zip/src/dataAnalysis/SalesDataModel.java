/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAnalysis;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author vaios
 */
public class SalesDataModel {
    
  private final StringProperty product;
  private final StringProperty number;
  private final StringProperty date;
  
  // constructor 
  public SalesDataModel(String product, String number, String date)
  {
    this.product = new SimpleStringProperty(product);
    this.number = new SimpleStringProperty(number);
    this.date = new SimpleStringProperty(date);
    
  }
  
  // getter methods
  public String getProduct()
  {
    return (String)this.product.get();
  }
  
  public String getNumber()
  {
    return (String)this.number.get();
  }
  
  public String getDate()
  {
    return (String)this.date.get();
  }
  
  // setter methods
  public void setProduct(String value)
  {
    this.product.set(value);
  }
  
  public void setNumber(String value)
  {
    this.number.set(value);
  }
  
  public void setDate(String value)
  {
    this.date.set(value);
  }
  
  // StringProperty methods
  public StringProperty productProperty()
  {
    return this.product;
  }
  
  public StringProperty numberProperty()
  {
    return this.number;
  }
  
  public StringProperty dateProperty()
  {
    return this.date;
  }
  
  
}
