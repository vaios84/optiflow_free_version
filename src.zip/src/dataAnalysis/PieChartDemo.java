
package dataAnalysis;

import dbUtil.dbConnection;
import dbUtil.loadCategories;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
//import org.jfree.data.time.Month;
//import org.jfree.data.time.TimeSeries;

/**
 *
 * @author vaios
 */
public class PieChartDemo {
    
    // create a list to load the categories later
    private ObservableList<String> list = FXCollections.observableArrayList();
    
    protected final int year1;
    protected final int year2;
    
    //the constructor of the class
    public PieChartDemo (int y1, int y2){
        
        year1 = y1;
        year2 = y2;
        
        
    }
    
    public void createThePieChart(){
            // create the dataset
            DefaultPieDataset data = new DefaultPieDataset();
            
            // populating the list with the categories from the sql database
            loadCategories ob1 = new loadCategories();
            list = ob1.getCategories();
            
            // calculate the sales for each category in the categories list
            int value0 = createDataSetValue(list.get(0));
            int value1 = createDataSetValue(list.get(1));
            int value2 = createDataSetValue(list.get(2));
            int value3 = createDataSetValue(list.get(3));
            int value4 = createDataSetValue(list.get(4));
            int value5 = createDataSetValue(list.get(5));
            int value6 = createDataSetValue(list.get(6));
            
            // set the data (names and sales number for the slices) for the piechart
            data.setValue(list.get(0) + "("+value0 + ")", value0);
            data.setValue(list.get(1) + "("+value1 + ")", value1);
            data.setValue(list.get(2) + "("+value2 + ")", value2);
            data.setValue(list.get(3) + "("+value3 + ")", value3);
            data.setValue(list.get(4) + "("+value4 + ")", value4);
            data.setValue(list.get(5) + "("+value5 + ")", value5);
            data.setValue(list.get(6) + "("+value6 + ")", value6);
            
            // create the chart
            JFreeChart chart = ChartFactory.createPieChart(
            "Sales per Category Piechart ("+year1 +"-"+year2 + ")" ,
            data,
            true,
            // legend?
            true,
            // tooltips?
            false
            // URLs?
            );
            // create and display a frame...
            ChartFrame frame = new ChartFrame("optiflow", chart);
            frame.pack();
            frame.setVisible(true);
        
    }
    
    
    public int createDataSetValue(String name) { // the argument (string name) of this method is the category 
        int result=0;
        
        ArrayList<String> list1 = new ArrayList<>();    // store all the the product ids that belong to the specific category 
        int[] list2 = new int[12];                      // store the sales of each month for the specific category 
        
        try{
                Connection conn = dbConnection.getConnection();
                
                ResultSet rs= conn.createStatement().executeQuery("SELECT productID FROM products WHERE category = '" + name + "'");
                
                // the list will now store all the product ids that belong to the specific category 
                //first check if the result set is empty
                if (rs.next() == false) {
                            System.out.println("ResultSet is empty");
                } else {
                            
                        do {
                            list1.add(rs.getString(1)); 
          
                        } while (rs.next());

                }

                rs.close();
                conn.close();            
          } catch(SQLException e){
              System.err.println("Error " + e);   
          }
        
        
        //iterating through all the years period selected by the user 
        for(int year=year1; year<=year2; year++) {
            
            // initialize to 0 the sum of sales for every month of the current year
            list2[0]=0; list2[1]=0; list2[2]=0; list2[3]=0; list2[4]=0; list2[5]=0;
            list2[6]=0; list2[7]=0; list2[8]=0; list2[9]=0; list2[10]=0; list2[11]=0;
            
            //iterating through all months 
            for (int i = 1; i <=12; i++) {

                //iterating through all the product ids of the first ArrayList
                for(String str: list1)  {
                    Connection conn;
                    try {
                        conn = dbConnection.getConnection();

                        ResultSet rs2;
                        if (i<10)
                            rs2 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE productID = '" + str + "' AND strftime('%m',date) LIKE ('0" + i +"') AND strftime('%Y',date) LIKE ('"+ year +"')"); 
                        else
                            rs2 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE productID = '" + str + "' AND strftime('%m',date) LIKE ('" + i +"') AND strftime('%Y',date) LIKE ('" + year +"')");

                        
                        if (rs2.next() == false) {
                            System.out.println("ResultSet is empty");
                        } else {
                            
                            do {
                                list2[i-1] = list2[i-1] + rs2.getInt(1);
          
                            } while (rs2.next());

                        }
                        
                        rs2.close();
                        conn.close();
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(ChartPanelDemo.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    
                }  

                
                
            }
            
            //calculate the sum of all the months sales for the current year and then add the next years too...
            // list2 has the sales of each month for the specific category 
            for(int x: list2)
                result = result +x;
        
        }
        
        
        return result;
    }
        
}
