
package dataAnalysis;

/**
 *
 * @author vaios
 */

import dbUtil.dbConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Month;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;


public class ChartPanelTotalSales extends ChartPanelDemo {
    
    public ChartPanelTotalSales(int isSelected1, int isSelected2, int isSelected3, int isSelected4, int isSelected5, int isSelected6, int isSelected7, int fromyear, int toyear) {
        super(isSelected1, isSelected2, isSelected3, isSelected4, isSelected5, isSelected6, isSelected7, fromyear, toyear);
    
    
    }
    
    @Override
    public ChartPanel createChart(){
    
        XYDataset dataset = createDataset(0, 0, 0, 0, 0, 0, 0);
        
        JFreeChart chart = ChartFactory.createTimeSeriesChart(
            title, "Date", "Sales", dataset, true, true, false);
        XYPlot plot = chart.getXYPlot();
        XYLineAndShapeRenderer renderer =
            (XYLineAndShapeRenderer) plot.getRenderer();
        renderer.setBaseShapesVisible(true);
        
        // The code below (in comments) gives a value of dollar currency in the Y axis
        //NumberFormat currency = NumberFormat.getCurrencyInstance();
        //currency.setMaximumFractionDigits(0);
        
        NumberFormat salesNumber = NumberFormat.getIntegerInstance();
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setNumberFormatOverride(salesNumber);
        
        return new ChartPanel(chart);
    
    }
    
    @Override
    public XYDataset createDataset(int x, int y, int z, int w, int q, int a, int p) {
        TimeSeriesCollection tsc = new TimeSeriesCollection();
        tsc.addSeries(createSeries("Total Sales"));
                
        return tsc;
        
    }
    
    @Override
    public TimeSeries createSeries(String name) { // name argument of this method is the category name 
        
        int[] list2 = new int[12];     // store the sales of each month for the current year
        
        TimeSeries series = new TimeSeries(name);
        
        //iterating through all the years period selected by the user 
        for(int year=year1; year<=year2; year++) {
            
            // initialize to 0 the sum of sales for every month of the current year
            list2[0]=0;list2[1]=0;list2[2]=0;list2[3]=0;list2[4]=0;list2[5]=0;
            list2[6]=0;list2[7]=0;list2[8]=0;list2[9]=0;list2[10]=0;list2[11]=0;
            
            //iterating through all months of the current year
            for (int i = 1; i <=12; i++) {

                Connection conn;
                try {
                    conn = dbConnection.getConnection();

                    ResultSet rs2;
                    if (i<10)
                        rs2 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE strftime('%m',date) LIKE ('0" + i +"') AND strftime('%Y',date) LIKE ('"+ year +"')"); 
                    else
                        rs2 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE strftime('%m',date) LIKE ('" + i +"') AND strftime('%Y',date) LIKE ('" + year +"')");


                    if (rs2.next() == false) {
                            System.out.println("ResultSet is empty");
                    } else {
                            
                        do {
                            list2[i-1] = list2[i-1] + rs2.getInt(1);
          
                        } while (rs2.next());

                    }
                    
                   
                } catch (SQLException ex) {
                    Logger.getLogger(ChartPanelDemo.class.getName()).log(Level.SEVERE, null, ex);
                }

                series.add(new Month(i , year), list2[i-1]);
                
            }
        
        }
        
        return series;
    }

    
    
    
}
