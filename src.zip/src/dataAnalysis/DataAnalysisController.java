
package dataAnalysis;

import alertBox.AlertBox;
import dbUtil.loadCategories;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;

/**
 *
 * @author vaios
 */
public class DataAnalysisController implements Initializable {
    
    private int sel1;
    private int sel2;
    private int sel3;
    private int sel4;
    private int sel5;
    private int sel6;
    private int sel7;
    
    private int y1=2019;
    private int y2=2028;
    
    //buttons
    @FXML
    private Button graphbutton;
    @FXML
    private Button clearbutton;
    @FXML
    private Button selectAllbutton;
    @FXML
    private Button graphTotalbutton;
    
    @FXML
    private Button createPiechartbutton;
    
    @FXML
    private Button info1button;
    @FXML
    private Button info2button;
    @FXML
    private Button info3button;

    // create the checkBoxes
    @FXML
    private CheckBox cb1;
    @FXML
    private CheckBox cb2;
    @FXML
    private CheckBox cb3;
    @FXML
    private CheckBox cb4;
    @FXML
    private CheckBox cb5;
    @FXML
    private CheckBox cb6;
    @FXML
    private CheckBox cb7; 

    //create ComboBoxes for year selection
    // create combobox quantity and a list to connect it later inside initialize function
    @FXML
    private ComboBox<Integer> fromyearCombo;
    @FXML
    private ComboBox<Integer> toyearCombo;
    
    @FXML
    private ComboBox<Integer> fromyearCombo2;
    @FXML
    private ComboBox<Integer> toyearCombo2;
    
    @FXML
    private ComboBox<Integer> fromyearCombo3;
    @FXML
    private ComboBox<Integer> toyearCombo3;
    
    private ObservableList<Integer> yearlist = FXCollections.observableArrayList(2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028);
    
    //create a list to load the categories from the sql database
    private ObservableList<String> list = FXCollections.observableArrayList();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) { 
        
        // populating the list with the categories from the sql database
        loadCategories ob1 = new loadCategories();
        list = ob1.getCategories();
        
        cb1.setText(list.get(0));
        cb2.setText(list.get(1));
        cb3.setText(list.get(2));
        cb4.setText(list.get(3));
        cb5.setText(list.get(4));
        cb6.setText(list.get(5));
        cb7.setText(list.get(6));
       

        // connect comboboxes and list of years
        fromyearCombo.setItems(yearlist);
        toyearCombo.setItems(yearlist);
        
        fromyearCombo2.setItems(yearlist);
        toyearCombo2.setItems(yearlist);
        
        fromyearCombo3.setItems(yearlist);
        toyearCombo3.setItems(yearlist);
        
        sel1=0; sel2=0; sel3=0; sel4=0;
        sel5=0; sel6=0; sel7=0;
        
    }
    
    @FXML
    public void createGraph(ActionEvent e){
        
            if(cb1.isSelected()) sel1=1;
                else sel1=0;
            if(cb2.isSelected()) sel2=1;
                else sel2=0;
            if(cb3.isSelected()) sel3=1;
                else sel3=0;
            if(cb4.isSelected()) sel4=1;
                else sel4=0;
            if(cb5.isSelected()) sel5=1;
                else sel5=0;
            if(cb6.isSelected()) sel6=1;
                else sel6=0;
            if(cb7.isSelected()) sel7=1;
                else sel7=0;
            
            boolean isyear1Empty = fromyearCombo.getSelectionModel().isEmpty();
            
            if(!isyear1Empty) y1= this.fromyearCombo.getValue();
                else y1=2019;
            
            boolean isyear2Empty = toyearCombo.getSelectionModel().isEmpty();
            
            if(!isyear2Empty) y2= this.toyearCombo.getValue();
                else y2=2028;
            
            if(y1>y2){   // if user has selected start year bigger from the final year. example 2021> 2019
                this.toyearCombo.setValue(y1);
                y2=y1;
            }
            
            Platform.runLater(new Runnable() {
            @Override
            public void run() {
                // create the graph
                ChartPanelDemo cpd = new ChartPanelDemo(sel1, sel2, sel3, sel4, sel5, sel6, sel7, y1, y2);
                cpd.initiateJFrame();
            
                }
            }); 
         
    }
    
    @FXML
    public void createTotalSalesGraph(ActionEvent e){
        
            boolean isyear1Empty = fromyearCombo2.getSelectionModel().isEmpty();
            
            if(!isyear1Empty) y1= this.fromyearCombo2.getValue();
            else y1=2019;
            
            boolean isyear2Empty = toyearCombo2.getSelectionModel().isEmpty();
            
            if(!isyear2Empty) y2= this.toyearCombo2.getValue();
            else y2=2028;
            
            if(y1>y2){   // if user has selected start year bigger from the final year. example: from2021> to2019
            
                this.toyearCombo2.setValue(y1);
                y2=y1;
                
            }
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                // create the graph
                ChartPanelTotalSales ob = new ChartPanelTotalSales(0,0,0,0,0,0,0, y1, y2);
                ob.initiateJFrame();
            
            }
        }); 
         
    }
    
    @FXML
    public void createPieChart (ActionEvent e){
        
            boolean isyear11Empty = fromyearCombo3.getSelectionModel().isEmpty();
            
            if(!isyear11Empty) y1= this.fromyearCombo3.getValue();
            else y1=2019;
            
            boolean isyear22Empty = toyearCombo3.getSelectionModel().isEmpty();
            
            if(!isyear22Empty) y2= this.toyearCombo3.getValue();
            else y2=2028;
            
            if(y1>y2){   // if user has selected start year bigger from the final year. example: from2021> to2019
            
                this.toyearCombo3.setValue(y1);
                y2=y1;
                
            }
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                // create the piechart
                PieChartDemo pie = new PieChartDemo(y1, y2);
                pie.createThePieChart();
            }
        }); 
         
    }
    
    
    @FXML
    public void clearCheckboxes(ActionEvent e){
        
        cb1.setSelected(false);
        cb2.setSelected(false);
        cb3.setSelected(false);
        cb4.setSelected(false);
        cb5.setSelected(false);
        cb6.setSelected(false);
        cb7.setSelected(false);       
    
    }
    
    @FXML
    public void selectAllCheckboxes(ActionEvent e){
        
        cb1.setSelected(true);
        cb2.setSelected(true);
        cb3.setSelected(true);
        cb4.setSelected(true);
        cb5.setSelected(true);
        cb6.setSelected(true);
        cb7.setSelected(true);       
    
    }
    
      @FXML
      public void info1Alert(){

            //show the alert
            AlertBox ob1 = new AlertBox();
            ob1.showGraphAlert1();

      }

      @FXML
      public void info2Alert(){

            //show the alert
            AlertBox ob1 = new AlertBox();
            ob1.showGraphAlert2();

      }


      @FXML
      public void info3Alert(){

            //show the alert
            AlertBox ob1 = new AlertBox();
            ob1.showGraphAlert3();

      }
    
    
}
