
package dataAnalysis;


import dbUtil.dbConnection;
import dbUtil.loadCategories;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.AbstractAction;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Month;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

public class ChartPanelDemo {

    protected final static String title = "Sales Data Graph";
    protected ChartPanel chartPanel;
    
    protected ObservableList<SalesDataModel> data;
    protected final dbConnection dc;
    
    protected final int sel1;
    protected final int sel2;
    protected final int sel3;
    protected final int sel4;
    protected final int sel5;
    protected final int sel6;
    protected final int sel7;
    
    protected final int year1;
    protected final int year2;
    
    // Constructor
    public ChartPanelDemo(int isSelected1, int isSelected2, int isSelected3, int isSelected4, int isSelected5, int isSelected6, int isSelected7, int fromyear, int toyear) {
        
        sel1 =isSelected1;
        sel2 =isSelected2;
        sel3 =isSelected3;
        sel4 =isSelected4;
        sel5 =isSelected5;
        sel6 =isSelected6;
        sel7 =isSelected7;
        year1 = fromyear;
        year2 = toyear;
        
        // create a connection with the database
         this.dc = new dbConnection();
                
    }
    
    
    public void initiateJFrame(){
                
        chartPanel = createChart();
        
        JFrame f = new JFrame(title);
        f.setTitle(title);
        // EXIT_ON_CLOSE will terminate the whole app
        //f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // DISPOSE_ON_CLOSE will not cause the whole app termination
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setLayout(new BorderLayout(0, 5));
        f.add(chartPanel, BorderLayout.CENTER);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setHorizontalAxisTrace(true);
        chartPanel.setVerticalAxisTrace(true);

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.add(createTrace());
        panel.add(createDate());
        panel.add(createZoom());
        f.add(panel, BorderLayout.SOUTH);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        
    }
    
    // loadSalesData function to load initially the data from sales
    public void loadSalesData() {

          try{
                Connection conn = dbConnection.getConnection();
                this.data = FXCollections.observableArrayList();

                ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM sales");
                
                if (rs.next() == false) {
                    System.out.println("ResultSet is empty!");
                } else {

                    do {
                        this.data.add(new SalesDataModel(rs.getString(1), rs.getString(2), rs.getString(3)));
                    } while (rs.next());
                }

                rs.close();
                conn.close();            
          } catch(SQLException e){
              System.err.println("Error " + e);   
          }

    } 
    
    
    public JComboBox createTrace() {
        final JComboBox trace = new JComboBox();
        final String[] traceCmds = {"Enable Trace", "Disable Trace"};
        trace.setModel(new DefaultComboBoxModel(traceCmds));
        trace.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (traceCmds[0].equals(trace.getSelectedItem())) {
                    chartPanel.setHorizontalAxisTrace(true);
                    chartPanel.setVerticalAxisTrace(true);
                    chartPanel.repaint();
                } else {
                    chartPanel.setHorizontalAxisTrace(false);
                    chartPanel.setVerticalAxisTrace(false);
                    chartPanel.repaint();
                }
            }
        });
        return trace;
    }

    public JComboBox createDate() {
        final JComboBox date = new JComboBox();
        final String[] dateCmds = {"Horizontal Dates", "Vertical Dates"};
        date.setModel(new DefaultComboBoxModel(dateCmds));
        date.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JFreeChart chart = chartPanel.getChart();
                XYPlot plot = (XYPlot) chart.getPlot();
                DateAxis domain = (DateAxis) plot.getDomainAxis();
                if (dateCmds[0].equals(date.getSelectedItem())) {
                    domain.setVerticalTickLabels(false);
                } else {
                    domain.setVerticalTickLabels(true);
                }
            }
        });
        return date;
    }

    public JButton createZoom() {
        final JButton auto = new JButton(new AbstractAction("Auto Zoom") {

            @Override
            public void actionPerformed(ActionEvent e) {
                chartPanel.restoreAutoBounds();
            }
        });
        return auto;
    }

    public ChartPanel createChart(){
        
        XYDataset dataset = createDataset(this.sel1, this.sel2, this.sel3, this.sel4, this.sel5, this.sel6, this.sel7);
        
        JFreeChart chart = ChartFactory.createTimeSeriesChart(
            title, "Date", "Sales", dataset, true, true, false);
        XYPlot plot = chart.getXYPlot();
        XYLineAndShapeRenderer renderer =
            (XYLineAndShapeRenderer) plot.getRenderer();
        renderer.setBaseShapesVisible(true);
        
        // The code below (in comments) gives a value of dollar currency in the Y axis
        //NumberFormat currency = NumberFormat.getCurrencyInstance();
        //currency.setMaximumFractionDigits(0);
        
        NumberFormat salesNumber = NumberFormat.getIntegerInstance();
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setNumberFormatOverride(salesNumber);
        
        return new ChartPanel(chart);
        
    }

    public XYDataset createDataset(int x, int y, int z, int w, int q, int a, int p) {
        
        ObservableList<String> list = FXCollections.observableArrayList();
        // populating the list with the categories from the sql database
        loadCategories ob1 = new loadCategories();
        list = ob1.getCategories();
                
        TimeSeriesCollection tsc = new TimeSeriesCollection();
        
        if(x==1) tsc.addSeries(createSeries(list.get(0)));
        if(y==1) tsc.addSeries(createSeries(list.get(1)));
        if(z==1) tsc.addSeries(createSeries(list.get(2)));
        if(w==1) tsc.addSeries(createSeries(list.get(3)));
        if(q==1) tsc.addSeries(createSeries(list.get(4)));
        if(a==1) tsc.addSeries(createSeries(list.get(5)));
        if(p==1) tsc.addSeries(createSeries(list.get(6)));
        
        return tsc;
        
    }

    public TimeSeries createSeries(String name) { // name argument of this method is the category name 
        
        ArrayList<String> list1 = new ArrayList<>();    // store all the the product ids that belong to the specific category 
        int[] list2 = new int[12];                      // store the sales of each month for the specific category 
        
        try{
                Connection conn = dbConnection.getConnection();
                
                ResultSet rs = conn.createStatement().executeQuery("SELECT productID FROM products WHERE category = '" + name + "'");

                // the list will now store all the product ids that belong to the specific category 
                
                if (rs.next() == false) {
                    System.out.println("ResultSet is empty!");
                } else {

                    do {
                        list1.add(rs.getString(1));
                    } while (rs.next());
                }
                
                rs.close();
                conn.close();            
          } catch(SQLException e){
              System.err.println("Error " + e);   
          }
        
        
        TimeSeries series = new TimeSeries(name);
        
        //iterating through all the years period selected by the user 
        for(int year=year1; year<=year2; year++) {
            
            // initialize to 0 the sum of sales for every month of the current year
            list2[0]=0;list2[1]=0;list2[2]=0;list2[3]=0;list2[4]=0;list2[5]=0;
            list2[6]=0;list2[7]=0;list2[8]=0;list2[9]=0;list2[10]=0;list2[11]=0;
            
            //iterating through all months 
            for (int i = 1; i <=12; i++) {

                //iterating through all the product ids of the first ArrayList
                for(String str: list1)  {
                    Connection conn;
                    try {
                        conn = dbConnection.getConnection();

                        ResultSet rs2;
                        if (i<10)
                            rs2 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE productID = '" + str + "' AND strftime('%m',date) LIKE ('0" + i +"') AND strftime('%Y',date) LIKE ('"+ year +"')"); 
                        else
                            rs2 = conn.createStatement().executeQuery("SELECT items FROM sales WHERE productID = '" + str + "' AND strftime('%m',date) LIKE ('" + i +"') AND strftime('%Y',date) LIKE ('" + year +"')");

                        
                        if (rs2.next() == false) {
                            System.out.println("ResultSet is empty");
                        } else {
                            
                            do {
                                list2[i-1] = list2[i-1] + rs2.getInt(1);
          
                            } while (rs2.next());

                        }

                        rs2.close();
                        conn.close();
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(ChartPanelDemo.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    
                }  

                series.add(new Month(i , year), list2[i-1]);
                
            }
        
        }
        
        return series;
    }

    
}