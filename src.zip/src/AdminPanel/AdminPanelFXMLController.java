
package AdminPanel;

import dataAnalysis.DataAnalysisController;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import loginapp.LoginMainController;
import settings.SettingsController;
import suppliers.SuppliersFXMLController;

public class AdminPanelFXMLController implements Initializable {
    
    @FXML
    private Button userspanelbutton;
    @FXML
    private Button supplierspanelbutton;
    @FXML
    private Button productspanelbutton;
    @FXML
    private Button dataAnalysispanelbutton;
    @FXML
    private Button openSettingsButton;
    
    @FXML
    private ImageView imageView1;
    
    @FXML
    private ImageView imageView2;
    
    @FXML
    private ImageView imageView3;
    
    @FXML
    private ImageView imageView4;
    
    private LoginMainController loginObject = new LoginMainController();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) { }
    
    // open the users window
    @FXML
    private void gotoUsers(ActionEvent event){
      loginObject.adminLogin();
    }
    
    //open the products window
    @FXML
    private void gotoProducts(ActionEvent event){
      loginObject.studentLogin2();
    }
    
    
    // open the suppliers window
    @FXML
    public void gotoSuppliers(ActionEvent event){
        
        try
        {
            Stage supplierStage = new Stage();
            FXMLLoader supplierLoader = new FXMLLoader();
            Pane supplierroot = (Pane)supplierLoader.load(getClass().getResource("/suppliers/suppliersFXML.fxml").openStream());
            SuppliersFXMLController suppliersController = (SuppliersFXMLController)supplierLoader.getController();
      
            Scene supplierscene = new Scene(supplierroot);
            supplierscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());
            
            // change the default app icon appearing on the system tray. working only for windows OS.
            Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
            supplierStage.getIcons().add(icon);
            
            supplierStage.initModality(Modality.NONE);
            //supplierStage.initModality(Modality.APPLICATION_MODAL); //Block events to other windows, but deletes the minimize button and functionality
            supplierStage.setScene(supplierscene);
            supplierStage.setTitle("OPTIFLOW v1.0 ");
            supplierStage.setResizable(true); 
            supplierStage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        
      
    }
    
    //open the data analysis window
    
    @FXML
    public void gotoDataAnalysis(ActionEvent event){
        
        try
        {
            Stage dataAnalysisStage = new Stage();
            FXMLLoader myLoader = new FXMLLoader();
            Pane myroot = (Pane)myLoader.load(getClass().getResource("/dataAnalysis/dataAnalysisFXML.fxml").openStream());
            DataAnalysisController myController = (DataAnalysisController)myLoader.getController();
      
            Scene myscene = new Scene(myroot);
            myscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());
            
            // change the default app icon appearing on the system tray. working only for windows OS.
            Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
            dataAnalysisStage.getIcons().add(icon);
            
            dataAnalysisStage.initModality(Modality.NONE);
            //dataAnalysisStage.initModality(Modality.APPLICATION_MODAL); //Block events to other windows, but deletes the minimize button and functionality
            dataAnalysisStage.setScene(myscene);
            dataAnalysisStage.setTitle("OPTIFLOW v1.0 ");
            dataAnalysisStage.setResizable(true); 
            dataAnalysisStage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    
    
    
    
    }
    
    
    
    @FXML
    public void openSettingsWindow(ActionEvent event){
        
        try
        {
            Stage settingStage = new Stage();
            FXMLLoader myLoader = new FXMLLoader();
            Pane myPane = (Pane)myLoader.load(getClass().getResource("/settings/settingsFXML.fxml").openStream());
            SettingsController myController = (SettingsController)myLoader.getController();
      
            Scene myscene = new Scene(myPane);
            myscene.getStylesheets().add(getClass().getResource("/CSS/mymaincss.css").toExternalForm());
            
            // change the default app icon appearing on the system tray. working only for windows OS.
            Image icon = new Image(getClass().getResourceAsStream("/img/image.png"));
            settingStage.getIcons().add(icon);
            
            settingStage.initModality(Modality.NONE);
            settingStage.initModality(Modality.APPLICATION_MODAL); //Block events to other windows, and deletes the minimize button and functionality
            settingStage.setScene(myscene);
            settingStage.setTitle("OPTIFLOW v1.0 ");
            settingStage.setResizable(false); 
            settingStage.show();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    
    
    
    
    }
    
    
    
}
