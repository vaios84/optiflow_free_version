/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package settings;

import alertBox.AlertBox;
import com.sun.javafx.util.Utils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import students.StudentsFXMLController;
import dbUtil.loadCategories;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author vaios
 */

public class SettingsController implements Initializable {
    
        @FXML
        private Button clearButton;        
        @FXML
        private Button saveButton;        
        @FXML
        private Button closeButton;
        
        @FXML
        private Label cat1;
        @FXML
        private Label cat2;
        @FXML
        private Label cat3;
        @FXML
        private Label cat4;
        @FXML
        private Label cat5;
        @FXML
        private Label cat6;
        @FXML
        private Label cat7;
                
        @FXML
        private TextField limit1;
        @FXML
        private TextField limit2;
        @FXML
        private TextField limit3;  
        @FXML
        private TextField limit4;
        @FXML
        private TextField limit5;
        @FXML
        private TextField limit6;
        @FXML
        private TextField limit7;
        
        // create an empty array list for the categories        
        private ObservableList<String> list1 = FXCollections.observableArrayList();
        
        @Override
        public void initialize(URL url, ResourceBundle rb) {
        
            // loading the categories
            loadCategories ob1 = new loadCategories();
            list1= ob1.getCategories();
            
            this.cat1.setText(list1.get(0).toString());
            this.cat2.setText(list1.get(1).toString());
            this.cat3.setText(list1.get(2).toString());
            this.cat4.setText(list1.get(3).toString());
            this.cat5.setText(list1.get(4).toString());
            this.cat6.setText(list1.get(5).toString());
            this.cat7.setText(list1.get(6).toString());
            
             // loading of the current qty-alert settings 
            settingsReadFunction2();
            
        }
        
        @FXML
        public void settingsWriteFunction(ActionEvent event) {
                        
            ArrayList<Integer> limits = new ArrayList<>();
            
            Integer value=0;
            
            if (this.limit1.getText().length() !=0) 
                value = Integer.valueOf(limit1.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            if (this.limit2.getText().length() !=0) 
                value = Integer.valueOf(limit2.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            if (this.limit3.getText().length() !=0) 
                value = Integer.valueOf(limit3.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            if (this.limit4.getText().length() !=0) 
                value = Integer.valueOf(limit4.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            if (this.limit5.getText().length() !=0) 
                value = Integer.valueOf(limit5.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            if (this.limit6.getText().length() !=0) 
                value = Integer.valueOf(limit6.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            if (this.limit7.getText().length() !=0) 
                value = Integer.valueOf(limit7.getText());
            else 
                value=0;
            
            if (value<0) value=0;
            limits.add(value);
            
            BufferedWriter bw = null;
            
            String currentDir;    // currentDir will hold the absolute path to 'home\'
             
            try {
                 
                if(Utils.isWindows()){
                     // this is where curDir gets set to the absolute path of 'home/'
                    currentDir = new File("").getAbsolutePath(); 
                    
                    String filePath = new StringBuilder().append(currentDir).append("\\settings-file.txt").toString();
                    
                    bw = new BufferedWriter(new FileWriter(new File(filePath), false)); // false word here enables to write from the beginning, not append
                
                }
                else{ //linux
                     bw = new BufferedWriter(new FileWriter(new File(new StringBuilder().append("settings-file.txt").toString()), false)); // false word here enables to write from the beginning, not append
                }
                 
                for(int x: limits){
                    bw.write(String.valueOf(x));
                    bw.append(System.lineSeparator()); // System.lineSeparator() instead of newline character (\n)
                                                        // because notepad can't read the newline character and shows everything in one line
                    
                }
                
                //show the alert
                AlertBox ob1 = new AlertBox();
                ob1.showLimitsUpdateAlert();  
                 
             } 
             catch (FileNotFoundException exx) {
                 exx.printStackTrace();

             }   
             catch (IOException ex) {
                  Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
             }

              try {
                  bw.close();
              } catch (IOException ex) {
                  Logger.getLogger(StudentsFXMLController.class.getName()).log(Level.SEVERE, null, ex);
              }

        }

        @FXML
        public ArrayList<Integer> settingsReadFunction(ActionEvent event) {
            
            ArrayList<Integer> list = new ArrayList<>();
            
            File file = new File("settings-file.txt");
            
            BufferedReader reader = null;

            try {
                reader = new BufferedReader(new FileReader(file));
                String text = null;

                while ((text = reader.readLine()) != null) {
                    list.add(Integer.parseInt(text));
                    
                }
                
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    
                }
            }
            
            this.limit1.setText(String.valueOf(list.get(0)));
            this.limit2.setText(String.valueOf(list.get(1)));
            this.limit3.setText(String.valueOf(list.get(2)));
            this.limit4.setText(String.valueOf(list.get(3)));
            this.limit5.setText(String.valueOf(list.get(4)));
            this.limit6.setText(String.valueOf(list.get(5)));
            this.limit7.setText(String.valueOf(list.get(6)));
            
            return list;
            
        }
        
        // used inside initialize method for initial loading of the settings
        public void settingsReadFunction2() {
            
            ArrayList<Integer> list = new ArrayList<>();
            
            File file = new File("settings-file.txt");
            
            BufferedReader reader = null;

            try {
                reader = new BufferedReader(new FileReader(file));
                String text = null;

                while ((text = reader.readLine()) != null) {
                    list.add(Integer.parseInt(text));
                    
                }
                
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                }
            }
            
            this.limit1.setText(String.valueOf(list.get(0)));
            this.limit2.setText(String.valueOf(list.get(1)));
            this.limit3.setText(String.valueOf(list.get(2)));
            this.limit4.setText(String.valueOf(list.get(3)));
            this.limit5.setText(String.valueOf(list.get(4)));
            this.limit6.setText(String.valueOf(list.get(5)));
            this.limit7.setText(String.valueOf(list.get(6)));
            
        }
        
        // used by other classes to load the limits
        public ArrayList<Integer> settingsReadFunction3() {
            
            ArrayList<Integer> list = new ArrayList<>();
            
            File file = new File("settings-file.txt");
            
            BufferedReader reader = null;

            try {
                reader = new BufferedReader(new FileReader(file));
                String text = null;

                while ((text = reader.readLine()) != null) {
                    list.add(Integer.parseInt(text));
                    
                }
                
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            return list;
            
        }
        
        
        @FXML
        public void clearFields(ActionEvent event) { 

          this.limit1.setText("0");  
          this.limit2.setText("0");
          this.limit3.setText("0");
          this.limit4.setText("0");
          this.limit5.setText("0");
          this.limit6.setText("0");
          this.limit7.setText("0");
          

        }
        
        @FXML
        public void closeWindow (ActionEvent event) {
            Stage stage = (Stage)this.closeButton.getScene().getWindow();
            stage.close();    
        
        }

    
    
}
